
college_years = ['f','s','j','ss']
# print(list(enumerate(college_years,2019)))

# print(list((x**2 for x in range (1,1001))))

d = ({x: x*x for x in range(1,1001)})
my_keys = d.keys()

p = {1,2,3,4}
p.add(6)
print(p)
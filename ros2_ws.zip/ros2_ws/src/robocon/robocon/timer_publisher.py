import rclpy
from rclpy.node import Node
from rclpy.qos import *
from std_msgs.msg import Float32
import time




class Time_Publisher(Node):
    
    def __init__(self):
        super().__init__('Time_Publisher')
        publisher = self.create_publisher(Float32,'/robocon',10)
        msgToSend = Float32()
        while True:
            msgToSend.data = time.time()
            publisher.publish(msgToSend)
            self.get_logger().info('Time : "%s"' % msgToSend.data)
            time.sleep(1)
        

def main(args=None):
    rclpy.init(args=args)
    node = Time_Publisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__=='__main__':
    main()
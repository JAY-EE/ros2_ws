import rclpy
import time
from rclpy.node import Node
from visual_kinematics.RobotSerial import *
#import msg_angle , msg_arm , msg_encoder
import numpy as np
#import msg_angle
from math import pi
import threading
from std_msgs.msg import String


np.set_printoptions(precision=3 , suppress=True)
dh_params = np.array([[4.5,4.0,-0.5*pi,0.5*pi],
                      [0.0,54.55,0.0,-0.5*pi],
                      [0.0,54.55,0.0*pi,0.5*pi]])
robot = RobotSerial(dh_params)


y = 0 
command = 'c'
position = 0
pitch = 0
yaw = 0
gripper = 0
is_preset = False
speed = 5

angles = {'first': 0, 'second': 0}
target = {'first': 0, 'second': 0}


class ArmServer(Node):
    global command
    def __init__(self):
        super().__init__('arm_server')

        self.pub = self.create_publisher(String, '/arm_angles_server', 10)
        self.sub_arm = self.create_subscription(String, '/arm_controller_server', self.arm_callback, 10)
        self.sub_angles = self.create_subscription(String, '/angle_feedback_server', self.angles_callback, 10)

        self.timer = self.create_timer(0.1, self.publisher)

    def arm_callback(self,msg):
        global command
        command = msg.data
        #self.position = msg.position
        #self.pitch = msg.pitch
        #self.yaw = msg.yaw
        #self.gripper = msg.gripper

    def angles_callback(self, msg):
        self.angles = {'first': msg.first, 'second': msg.second}

    def publisher(self):
            msg = String()
            #msg.y = float(self.y)
            #msg.first = float(self.target['first'])
            #msg.second = float(self.target['second'])
            #msg.pitch = float(self.pitch)
            #msg.yaw = float(self.yaw)
            #msg.gripper = int(self.gripper)
            msg.data = " recieved msg : " + command
            self.pub.publish(msg)
            #self.get_logger().info(" Publishing : '%s'" %command)



            if command == 'w':
        
                print('prssed command is w')

            elif command == 's':
            
                print('pressed command is s')
            
            elif command == '2':
            
                print('pressed command is 2')

            elif command == '8':
        
                print('pressed command is 8')
            else:
                print("enter valid command")


def go_to_pos1(self):
    self.target = {'first': 0, 'second': 0}
    self.work = True

def go_to_pos2(self):
    self.target = {'first': 10, 'second': 20}
    self.work = True

def main():
    global command
    global is_preset
    print('Arm server started')

    while rclpy.ok():
        angle_rad = {'first': angles['first'] * pi / 180, 'second': angles['second'] * pi / 180}
        theta = np.array([0, angle_rad['first'], angle_rad['second']])
        f = robot.forward(theta)
        x, y, z = f.t_3_1.reshape([3, ])

        if position == 1:
            go_to_pos1()
        elif position == 2:
            go_to_pos2()

        if command == 'w':
            is_preset = False
            xyz = np.array([[x], [y + speed], [z]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('prssed command is w')

        elif command == 's':
            is_preset = False
            xyz = np.array([[x], [y - speed], [z]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('pressed command is s')
            
        elif command == '2':
            iss_preset = False
            xyz = np.array([[x], [y], [z - speed]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('pressed command is 2')

        elif command == '8':
            is_preset = False
            xyz = np.array([[x], [y], [z + speed]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('pressed command is 8')
        else:
            print("command is c")

    rclpy.init(args=None)
    node = ArmServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


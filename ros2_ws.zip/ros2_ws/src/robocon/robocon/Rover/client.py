import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from datetime import datetime
import time

class TimePublisher(Node):

    def __init__(self):
        super().__init__('time_publisher')
        self.publisher_ = self.create_publisher(String, '/time_data', 10)
        self.timer = self.create_timer(1.0, self.timer_callback)  # Publish every second

    def timer_callback(self):
        msg = String()
        current_time = datetime.now().strftime("%H:%M:%S")
        msg.data = current_time
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%s"' % msg.data)

def main(args=None):
    rclpy.init(args=args)
    time_publisher = TimePublisher()
    
    rclpy.spin(time_publisher)
    
    time_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

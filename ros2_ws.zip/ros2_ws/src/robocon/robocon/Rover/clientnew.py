import asyncio
import websockets
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist

Ip = "170.171.172.70"
port_arm = 8765
port_chassis = 8766

async def arm_callback(msg):
    global recieved_arm

    recieved_arm = msg.data
    print(f"Command: {recieved_arm}")

    uri_arm = f"ws://{Ip}:{port_arm}"

    async with websockets.connect(uri_arm) as websocket:
        mesg = json.dumps({"command": recieved_arm})
        await websocket.send(mesg)

async def chassis_callback(msg):
    x = msg.linear.x
    y = msg.linear.y
    p = msg.linear.z
    ang_z = msg.angular.z

    print(f"Command: x={x}, y={y}, z={p}, ang_z={ang_z}")

    uri_chassis = f"ws://{Ip}:{port_chassis}"

    async with websockets.connect(uri_chassis) as websocket:
        mesg = json.dumps({
            "linear": {"x": x, "y": y, "z": p},
            "angular": {"z": ang_z}
        })
        await websocket.send(mesg)

def subscribers(node):
    node.create_subscription(Int32, '/arm_client', lambda msg: asyncio.ensure_future(arm_callback(msg)), 10)
    node.create_subscription(Twist, '/rover_client', lambda msg: asyncio.ensure_future(chassis_callback(msg)), 10)

async def main_async():
    rclpy.init(args=None)
    node = rclpy.create_node('Master_Client')

    subscribers(node)

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            await asyncio.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

def main():
    asyncio.run(main_async())

if __name__ == '__main__':
    main()

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool

class TimeServer(Node):

    def __init__(self):
        super().__init__('time_server')
        self.subscription = self.create_subscription(
            String,
            '/time_data',
            self.time_callback,
            10)
        self.publisher_ = self.create_publisher(Bool, '/time_feedback', 10)
        self.get_logger().info('Time Server has started.')

    def time_callback(self, msg):
        current_time = msg.data
        self.get_logger().info(f'Received time: {current_time}')
        
        # Process time and send feedback
        feedback = Bool()
        feedback.data = self.process_time(current_time)
        self.publisher_.publish(feedback)
        self.get_logger().info(f'Published feedback: {feedback.data}')

    def process_time(self, time_str):
        # A simple example process: return True if seconds part is even, else False
        try:
            seconds = int(time_str.split(':')[-1])
            return seconds % 2 == 0
        except (ValueError, IndexError):
            self.get_logger().error('Invalid time format received.')
            return False

def main(args=None):
    rclpy.init(args=args)
    time_server = TimeServer()
    
    rclpy.spin(time_server)
    
    time_server.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

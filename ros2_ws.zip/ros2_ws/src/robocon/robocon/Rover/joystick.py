import pygame
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Int32

# Initialize Pygame and ROS 2
pygame.init()
pygame.joystick.init()

rclpy.init(args=None)
node = rclpy.create_node('joystick_control')
publisher_rover = node.create_publisher(Twist, '/cmd_vel', 10)
publisher_arm = node.create_publisher(Int32,'/arm_commands',10)

# List to hold the joystick instances
joysticks = []

def pub():
    global publisher_rover,node
    msg_rover = Twist()
    msg_arm = Int32()

    for joystick in joysticks:
        frontback = joystick.get_axis(1) 
        rightleft = joystick.get_axis(3)

        arm1front = joystick.get_axis(2)
        arm2front = joystick.get_axis(5)

        arm2back = joystick.get_button(0)
        arm1back = joystick.get_button(5)

        gripper_close = joystick.get_button(4)
        gripper_open = joystick.get_button(5)

        yaw_forward  = joystick.get_button(3)
        yaw_backward  = joystick.get_button(8)

        roll_clockwise = joystick.get_button(1)
        roll_anticlockwise = joystick.get_button(2)

        if((frontback > 0) or (frontback < 0)):  # Horizontal movement
            x_axis = -1*frontback  
            y_axis = 0.0
            z_axis = 0.0

            msg_rover.linear.x = x_axis
            msg_rover.linear.y = y_axis
            msg_rover.linear.z = z_axis


        if((rightleft >0) or (rightleft <0)):  # vertical movement
           # x_axis = frontback 
           

            msg_rover.angular.z = -rightleft

        publisher_rover.publish(msg_rover)

        if((arm1front > 0)):
            msg_arm.data = 1
            publisher_arm.publish(msg_arm)

        if((arm2front > 0)):
            msg_arm.data = 2
            publisher_arm.publish(msg_arm)

        if((arm2back == 1) & (arm1back ==0)):
            msg_arm.data = 4
            publisher_arm.publish(msg_arm)

        if((arm2back == 1) & (arm1back == 1)):
            msg_arm.data = 3
            publisher_arm.publish(msg_arm)

        if((gripper_close == 1)):
            msg_arm.data = 5
            publisher_arm.publish(msg_arm)
        
        if((gripper_open == 1) & (arm2back ==0)):
            msg_arm.data = 6
            publisher_arm.publish(msg_arm)
        
        if((yaw_forward == 1)):
            msg_arm.data = 7
            publisher_arm.publish(msg_arm)
        
        if((yaw_backward == 1)):
            msg_arm.data = 8
            publisher_arm.publish(msg_arm)
        
        if((roll_clockwise == 1)):
            msg_arm.data = 9
            publisher_arm.publish(msg_arm)
        
        if((roll_anticlockwise == 1)):
            msg_arm.data = 10
            publisher_arm.publish(msg_arm)

        if((arm1back == 0) & (arm1front == -1) & (arm2back == 0) & (arm2front == -1) &
           (roll_clockwise == 0) & (roll_anticlockwise == 0) & (yaw_forward ==0)
           & (yaw_backward == 0) & (gripper_close == 0) & (gripper_open ==0)):
            msg_arm.data = 0
            publisher_arm.publish(msg_arm)

        

def process_events():
    global joysticks
    for event in pygame.event.get():
        if event.type == pygame.JOYDEVICEADDED:
            joystick = pygame.joystick.Joystick(event.device_index)
            joystick.init()
            joysticks.append(joystick)
        elif event.type == pygame.JOYBUTTONDOWN:
            print(f"Button {event.button} pressed")
            pass
        elif event.type == pygame.JOYAXISMOTION:
            print(f"Axis {event.axis} moved to {event.value:.1f}")
            pass

def main():
    global run
    run = True

    while run:
        process_events()
        pub()
        rclpy.spin_once(node, timeout_sec=0.1) 

        if joysticks and joysticks[0].get_button(10):
            run = False

    pygame.quit()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

import asyncio
import json
import rclpy
import threading
from rclpy.node import Node
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist

# Global publishers
publisher_arm = None
publisher_chassis = None

class UDPServerProtocol(asyncio.DatagramProtocol):
    def __init__(self):
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport
        print(f"Server listening on {transport.get_extra_info('sockname')}")

    def datagram_received(self, data, addr):
        message = data.decode('utf-8')
        print(f"Received message from {addr}: {message}")
        self.handle_message(message)

    def handle_message(self, message):
        try:
            data = json.loads(message)
            if 'command' in data:
                arm_command = Int32()
                arm_command.data = data.get("command", 0)
                publisher_arm.publish(arm_command)
            elif 'linear' in data or 'angular' in data:
                chassis_command = Twist()
                chassis_command.linear.x = data.get("linear", {}).get("x", 0.0)
                chassis_command.linear.y = data.get("linear", {}).get("y", 0.0)
                chassis_command.linear.z = data.get("linear", {}).get("z", 0.0)
                chassis_command.angular.z = data.get("angular", {}).get("z", 0.0)
                publisher_chassis.publish(chassis_command)
        except json.JSONDecodeError:
            print(f"Failed to decode JSON message: {message}")

async def start_server():
    global publisher_arm, publisher_chassis

    rclpy.init(args=None)
    node = rclpy.create_node('VideoGame_Server')

    # Publisher setup
    publisher_arm = node.create_publisher(Int32, '/arm_commands', 10)
    publisher_chassis = node.create_publisher(Twist, '/cmd_vel', 10)

    # UDP Server setup
    loop = asyncio.get_running_loop()
    connect = loop.create_datagram_endpoint(lambda: UDPServerProtocol(), local_addr=('localhost', 9999))
    transport, protocol = await connect

    # Spin the node in a separate thread to avoid blocking the asyncio loop
    rclpy_executor = rclpy.executors.MultiThreadedExecutor()
    rclpy_executor.add_node(node)
    rclpy_thread = threading.Thread(target=rclpy_executor.spin, daemon=True)
    rclpy_thread.start()

    try:
        while True:
            await asyncio.sleep(3600)  # Sleep for an hour, you can adjust this interval
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        rclpy_executor.shutdown()
        rclpy_thread.join()

def main():
    asyncio.run(start_server())

if __name__ == "__main__":
    main()

import asyncio
import json
import pygame
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32

class JoystickClient(Node):
    def __init__(self):
        super().__init__('joystick_client')
        self.publisher_arm = self.create_publisher(Int32, '/arm_client', 10)
        pygame.init()
        pygame.joystick.init()
        self.joystick = None
        if pygame.joystick.get_count() > 0:
            self.joystick = pygame.joystick.Joystick(0)
            self.joystick.init()
            print(f"Joystick connected: {self.joystick.get_name()}")
        else:
            print("No joystick detected.")

    def process_events(self):
        pygame.event.pump()
        if not self.joystick:
            return None

        axes = [self.joystick.get_axis(i) for i in range(self.joystick.get_numaxes())]
        buttons = [self.joystick.get_button(i) for i in range(self.joystick.get_numbuttons())]
        hat = self.joystick.get_hat(0) if self.joystick.get_numhats() > 0 else (0, 0)

        return {
            "axes": axes,
            "buttons": buttons,
            "hat": hat
        }

    async def publish_messages(self):
        while rclpy.ok():
            message = self.process_events()
            if message:
                # Convert joystick message to an Int32 command (example conversion)
                command = self.convert_message_to_command(message)
                self.publisher_arm.publish(Int32(data=command))
            await asyncio.sleep(0.05)  # Adjust this for your specific needs

    def convert_message_to_command(self, message):
        # Convert joystick message to Int32 command, adjust logic as needed
        # Placeholder logic: just return a dummy command
        return 0

    async def main(self):
        try:
            await self.publish_messages()
        finally:
            pygame.quit()
            self.destroy_node()
            rclpy.shutdown()

def main():
    rclpy.init(args=None)
    client = JoystickClient()
    asyncio.run(client.main())

if __name__ == '__main__':
    main()

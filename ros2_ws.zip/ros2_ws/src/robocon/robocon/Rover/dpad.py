import pygame

# Initialize pygame and joystick modules
pygame.init()
pygame.joystick.init()

def main():
    # Create a window
    pygame.display.set_mode((640, 480))
    
    # Check for available joysticks
    if pygame.joystick.get_count() == 0:
        print("No joysticks connected.")
        return
    
    # Initialize the first joystick
    joystick = pygame.joystick.Joystick(0)
    joystick.init()
    
    print("Joystick initialized.")
    
    running = True
    while running:
        # Process events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.JOYHATMOTION:
                # Get the state of the D-pad
                dpad = joystick.get_hat(0)
                dpad_x, dpad_y = dpad
                
                # Map D-pad directions to output
                if dpad_x == 1:
                    dpad_direction = 'Right'
                elif dpad_x == -1:
                    dpad_direction = 'Left'
                elif dpad_y == 1:
                    dpad_direction = 'Up'
                elif dpad_y == -1:
                    dpad_direction = 'Down'
                else:
                    dpad_direction = 'Center'
                
                # Print the D-pad direction
                print(f"D-pad Direction: {dpad_direction}")

        # Add a small delay to make sure the print statements are readable
        pygame.time.wait(100)

    pygame.quit()

if __name__ == "__main__":
    main()

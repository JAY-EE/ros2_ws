import pygame
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Int32

pygame.init()
pygame.joystick.init()

joysticks = []
run = True

def process_events():
    global joysticks
    for event in pygame.event.get():
        if event.type == pygame.JOYDEVICEADDED:
            joystick = pygame.joystick.Joystick(event.device_index)
            joystick.init()
            joysticks.append(joystick)
        elif event.type == pygame.JOYBUTTONDOWN:
            print(f"Button {event.button} pressed")
        elif event.type == pygame.JOYAXISMOTION:
            print(f"Axis {event.axis} moved to {event.value:.2f}")
            pass

def publish_messages(publisher_arm):
    msg_arm = Int32()
    
    if joysticks:
        joystick = joysticks[0]  # Use the first joystick

        arm1front = joystick.get_axis(2)
        arm2front = joystick.get_axis(5)

        arm2back = joystick.get_button(0)
        arm1back = joystick.get_button(5)

        gripper_close = joystick.get_button(4)
        gripper_open = joystick.get_button(5)

        yaw_forward  = joystick.get_button(3)
        yaw_backward  = joystick.get_button(8)

        roll_clockwise = joystick.get_button(1)
        roll_anticlockwise = joystick.get_button(2)

        if arm1front > 0:
            msg_arm.data = 1
        elif arm2front > 0:
            msg_arm.data = 2
        elif arm2back == 1 and arm1back == 0:
            msg_arm.data = 4
        elif arm2back == 1 and arm1back == 1:
            msg_arm.data = 3
        elif gripper_close == 1:
            msg_arm.data = 5
        elif gripper_open == 1 and arm2back == 0:
            msg_arm.data = 6
        elif yaw_forward == 1:
            msg_arm.data = 7
        elif yaw_backward == 1:
            msg_arm.data = 8
        elif roll_clockwise == 1:
            msg_arm.data = 9
        elif roll_anticlockwise == 1:
            msg_arm.data = 10
        else:
            msg_arm.data = 0
        
        publisher_arm.publish(msg_arm)

def main():
    global run

    rclpy.init(args=None)
    node = rclpy.create_node('publisher_node')
    publisher_arm = node.create_publisher(Int32, 'arm_client', 10)

    while run:
        process_events()
        publish_messages(publisher_arm)
        rclpy.spin_once(node, timeout_sec=0.1)

        if joysticks and joysticks[0].get_button(10):
            run = False

    pygame.quit()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

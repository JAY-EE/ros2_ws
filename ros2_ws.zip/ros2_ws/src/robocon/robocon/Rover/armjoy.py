import pygame
import rclpy
import serial
from rclpy.node import Node
from geometry_msgs.msg import Twist


SERIAL_PORT = '/dev/ttyACM0' 
BAUD_RATE = 9600
ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
#ser.write((msg).encode('utf-8'))


# Initialize Pygame and ROS 2
pygame.init()
pygame.joystick.init()

rclpy.init(args=None)
node = rclpy.create_node('joystick_control')
publisher = node.create_publisher(Twist, '/cmd_vel', 10)

# List to hold the joystick instances
joysticks = []

def pub():
    global publisher,node
    msg = Twist()

    for joystick in joysticks:
        frontback = joystick.get_axis(1) 
        rightleft = joystick.get_axis(3)

        if((frontback < 0)):
            msg = str(1)
            ser.write(msg.encode('utf-8'))
            print('1') 


        if((frontback > 0)):
            msg = str(2)
            ser.write(msg.encode('utf-8'))
            print('2')

        if((rightleft <0)): 
           msg = str(3)
           ser.write(msg.encode('utf-8'))
           print('3')
        
        if((rightleft > 0)):
           msg = str(4) 
           ser.write(msg.encode('utf-8'))
           print('4')

        

def process_events():
    global joysticks
    for event in pygame.event.get():
        if event.type == pygame.JOYDEVICEADDED:
            joystick = pygame.joystick.Joystick(event.device_index)
            joystick.init()
            joysticks.append(joystick)
        elif event.type == pygame.JOYBUTTONDOWN:
            #print(f"Button {event.button} pressed")
            pass
        elif event.type == pygame.JOYAXISMOTION:
            #print(f"Axis {event.axis} moved to {event.value:.2f}")
            pass

def main():
    global run
    run = True

    while run:
        process_events()
        pub()
        rclpy.spin_once(node, timeout_sec=0.1) 

        if joysticks and joysticks[0].get_button(2):
            run = False

    pygame.quit()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

import asyncio
import websockets

async def connect_and_receive(port):
    uri = f"ws://localhost:{port}"

    async with websockets.connect(uri) as websocket:
        mesg = input(f"Enter message for port {port}: ")
        await websocket.send(mesg)
        message = await websocket.recv()
        print(f"Received message from port {port}: {message}")

async def connect_to_servers():
    tasks = [
        connect_and_receive(8765),  # Port for arm
        connect_and_receive(8766),  # Port for chassis
        connect_and_receive(8767)   # Port for sciencebox
    ]
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    try:
        asyncio.run(connect_to_servers())
    except KeyboardInterrupt:
        print("Client stopped manually")

import asyncio
import websockets
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
import threading

Ip = "localhost"
port_arm = 8765

class MasterServer(Node):
    def __init__(self):
        super().__init__('master_server')
        self.publisher_arm = self.create_publisher(Int32, '/arm_commands', 10)

    async def handle_arm(self, websocket, path):
        async for message in websocket:
            print(f"Received message for arm: {message}")
            data = json.loads(message)
            arm_command = Int32()
            arm_command.data = data.get("command", 0)
            self.publisher_arm.publish(arm_command)
            await websocket.send(f"Published to arm: {arm_command.data}")

    async def start_server(self):
        server = await websockets.serve(self.handle_arm, Ip, port_arm, ping_timeout=None)
        print("Server started")
        try:
            await server.wait_closed()
        except KeyboardInterrupt:
            pass

def main():
    rclpy.init(args=None)
    node = MasterServer()

    rclpy_executor = rclpy.executors.SingleThreadedExecutor()  # Using SingleThreadedExecutor for lower latency
    rclpy_executor.add_node(node)

    # Run the ROS 2 node in a separate thread to avoid blocking the asyncio loop
    def ros_thread():
        rclpy_executor.spin()
    
    threading.Thread(target=ros_thread, daemon=True).start()

    try:
        asyncio.run(node.start_server())
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

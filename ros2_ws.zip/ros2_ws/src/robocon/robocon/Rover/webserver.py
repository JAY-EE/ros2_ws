import asyncio
import websockets

async def call(websocket, path):
    while True:
        try:
            message = await websocket.recv()
            print(f"Received message from client: {message}")
            await websocket.send(f"Received your message: {message}")
        except websockets.exceptions.ConnectionClosedError:
            print("Client disconnected")
            break

async def start_server():
    sserver = await websockets.serve(call, "localhost", 8765)  # Listen on all interfaces
    print("Server started")
    await sserver.wait_closed()

asyncio.run(start_server())

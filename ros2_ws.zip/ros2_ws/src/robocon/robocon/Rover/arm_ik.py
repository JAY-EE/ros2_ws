import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, Float32MultiArray
from visual_kinematics.RobotSerial import *
from visual_kinematics.RobotTrajectory import *
import numpy as np
import math
from math import pi

class InverseKinematicsNode(Node):
    def __init__(self):
        super().__init__('inverse_kinematics_node')

        self.encoder_subscription = self.create_subscription(
            Float32,
            'encoder_data',
            self.encoder_callback,
            10
        )
        self.actuator_publisher = self.create_publisher(
            Float32MultiArray,
            'actuator_control',
            10
        )

        self.end_effector = [0.2, 0.8, 0]
        self.eps = 0.001

    def inversekinematics(self, end_effector):
        np.set_printoptions(precision=3, suppress=True)

        dh_params = np.array([[0., 0.53, 0, pi/2],
                              [0., 0.53, 0, -pi/2]])

        robot = RobotSerial(dh_params)

        xyz = np.array([[end_effector[0]], [end_effector[1]], [end_effector[2]]])
        abc = np.array([pi, -pi, 0.])
        end = Frame.from_euler_3(abc, xyz)
        robot.inverse(end)
        z = robot.axis_values
        theta1 = pi/2 - z[0]  # Only one angle needed now

        return theta1

    def actuator_lengths(self, theta1):
        b = math.sqrt(584 - 440 * math.cos(theta1 - math.radians(13)))
        a = math.sqrt(1412.5 + 1396.5 * math.cos(theta1 - math.radians(22)))
        return a, b

    def encoder_callback(self, msg):
        self.get_logger().info(f'Received encoder data: {msg.data}')
        
        theta1i = msg.data  # Read the single encoder angle
        a0, b0 = self.actuator_lengths(theta1i)
        theta1f = self.inversekinematics([self.end_effector[0] + self.eps, self.end_effector[1], self.end_effector[2]])
        a, b = self.actuator_lengths(theta1f)

        dela, delb = a - a0, b - b0

        actuator_msg = Float32MultiArray()
        actuator_msg.data = [dela, delb]
        self.actuator_publisher.publish(actuator_msg)

        # Update the end-effector position for the next iteration
        self.end_effector[0] += self.eps
        self.get_logger().info(f'Updated x position: {self.end_effector[0]}')

def main(args=None):
    rclpy.init(args=args)
    node = InverseKinematicsNode()
    try:
        rclpy.spin(node)
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()

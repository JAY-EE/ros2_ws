import asyncio
import websockets
import json
import rclpy
import threading
from rclpy.node import Node
from std_msgs.msg import String, Int32
from geometry_msgs.msg import Twist

Ip = "localhost"
port_arm = 8765
port_chassis = 8766
# port_sciencebox = 8767

async def handle_arm(websocket, path):
    async for message in websocket:
        print(f"Received message for arm: {message}")
        data = json.loads(message)
        arm_command = Int32()
        arm_command.data = data.get("command", 0)
        publisher_arm.publish(arm_command)
        #await websocket.send(f"Published to arm: {arm_command.data}")


async def handle_chassis(websocket, path):
    async for message in websocket:
        print(f"Received message for chassis: {message}")
        data = json.loads(message)
        chassis_command = Twist()
        chassis_command.linear.x = data.get("linear", {}).get("x", 0.0)
        chassis_command.linear.y = data.get("linear", {}).get("y", 0.0)
        chassis_command.linear.z = data.get("linear", {}).get("z", 0.0)
        chassis_command.angular.z = data.get("angular", {}).get("z", 0.0)
        publisher_chassis.publish(chassis_command)
        #await websocket.send(f"Published to chassis: {message}")


# async def handle_sciencebox(websocket, path):
#     async for message in websocket:
#         print(f"Received message for sciencebox: {message}")
#         await websocket.send(f"Message received by sciencebox server: {message}")


# def time_callback(msg):
#     message = msg.data
#     print(f"Received feedback: {message}")


async def start_server():
    global publisher_arm, publisher_chassis

    rclpy.init(args=None)
    node = rclpy.create_node('Master_Server_Base')

    # Publisher setup
    publisher_arm = node.create_publisher(Int32, '/arm_commands', 10)
    publisher_chassis = node.create_publisher(Twist, '/cmd_vel', 10)

    # WebSocket server setup
    send_arm = await websockets.serve(handle_arm, Ip, port_arm, ping_timeout=None)
    send_chassis = await websockets.serve(handle_chassis, Ip, port_chassis, ping_timeout=None)
    # send_sciencebox = await websockets.serve(handle_sciencebox, Ip, port_sciencebox, ping_timeout=None)

    print("Server started")

    try:
        # Spin the node in a separate thread to avoid blocking the asyncio loop
        rclpy_executor = rclpy.executors.MultiThreadedExecutor()
        rclpy_executor.add_node(node)
        rclpy_thread = threading.Thread(target=rclpy_executor.spin, daemon=True)
        rclpy_thread.start()

        # Wait for WebSocket servers to close
        await asyncio.gather(
            send_arm.wait_closed(),
            send_chassis.wait_closed(),
            # send_sciencebox.wait_closed()
        )
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        rclpy_executor.shutdown()
        rclpy_thread.join()

def main():
    asyncio.run(start_server())

if __name__ == "__main__":
    main()

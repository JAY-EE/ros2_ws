import rclpy
from rclpy.node import Node
import time
import threading
from std_msgs.msg import *
from geometry_msgs.msg import PoseStamped
import math

class ChassisController(Node):
    def __init__(self):
        super().__init__('chassis_controller')
        
        self.left = 0
        self.right = 0
        self.x = 0
        self.y = 0
        self.is_pid = False
        self.yaw = 0
        self.reference_angle = 0

        self.publisher = self.create_publisher(String, '/rover_server', 10)
        self.subscription_control = self.create_subscription(
            String,
            '/rover_controller_server',
            self.control_callback,
            10
        )
        self.subscription_yaw = self.create_subscription(
            PoseStamped,
            '/zed2i/zed_node/pose',
            self.yaw_callback,
            10
        )

        self.timer = self.create_timer(0.01, self.publisher_callback)
        self.thread = threading.Thread(target=self.main)
        self.thread.start()

    def control_callback(self, msg):
        self.x = msg.x
        self.y = msg.y
        self.is_pid = msg.is_pid

    def yaw_callback(self, msg):
        qx = msg.pose.orientation.x
        qy = msg.pose.orientation.y
        qz = msg.pose.orientation.z
        qw = msg.pose.orientation.w
        self.yaw = math.atan2(2 * (qw * qz + qx * qy), 1 - 2 * (qy**2 + qz**2))

    def publisher_callback(self):
        msg_to_send = String()
        self.publisher.publish(msg_to_send)

    def main(self):
        self.get_logger().info('chassis_server.py')
        while rclpy.ok():
            if not self.is_pid:
                self.left = self.x + self.y
                self.right = self.x - self.y
                self.reference_angle = self.yaw
            else:
                diff = self.reference_angle - self.yaw
                correction = 19 * diff * self.x
                self.right = self.x + correction
                self.left = self.x - correction
            time.sleep(0.01)  # To prevent the loop from consuming too much CPU

def main(args=None):
    rclpy.init(args=args)
    chassis_controller = ChassisController()
    rclpy.spin(chassis_controller)
    chassis_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

import asyncio
import websockets

async def connect_and_send_message():
    uri = "ws://localhost:8765"  # Replace "localhost" with the server's IP address if needed
    while True:
        async with websockets.connect(uri) as websocket:
            message = input("Enter message to send: ")
            await websocket.send(message)
            print(f"Sent message: {message}")
    # except Exception as e:
    #     print(f"Error connecting or sending message: {e}")

async def main():
    await connect_and_send_message()

if __name__ == "__main__":
    asyncio.run(main())

import rclpy
from rclpy.node import Node
from rclpy.qos import *
from std_msgs.msg import String
from visual_kinematics.RobotSerial import *
import time

node = None
publisher = None
subscriber_arm = None
subscriber_angle = None

y = 0 
command = 'c'
position = 0
pitch = 0
yaw = 0
gripper = 0
is_preset = False
speed = 5

angles = {'first': 0, 'second': 0}
target = {'first': 0, 'second': 0}


np.set_printoptions(precision=3 , suppress=True)
dh_params = np.array([[4.5,4.0,-0.5*pi,0.5*pi],
                      [0.0,54.55,0.0,-0.5*pi],
                      [0.0,54.55,0.0*pi,0.5*pi]])
robot = RobotSerial(dh_params)


def arm_callback(msg):
        
        global command
        command = msg.data
        print("recieved command " + command)

        pub()

        angle_rad = {'first': angles['first'] * pi / 180, 'second': angles['second'] * pi / 180}
        theta = np.array([0, angle_rad['first'], angle_rad['second']])
        f = robot.forward(theta)
        x, y, z = f.t_3_1.reshape([3, ])

        if position == 1:
            go_to_pos1()
        elif position == 2:
            go_to_pos2()

        if command == 'w':
            is_preset = False
            xyz = np.array([[x], [y + speed], [z]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('prssed command is w')
    

        elif command == 's':
            is_preset = False
            xyz = np.array([[x], [y - speed], [z]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('pressed command is s')
        
            
        elif command == '2':
            iss_preset = False
            xyz = np.array([[x], [y], [z - speed]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('pressed command is 2')


        elif command == '8':
            is_preset = False
            xyz = np.array([[x], [y], [z + speed]])
            abc = np.array([0, 0, 0])
            end = Frame.from_euler_3(abc, xyz)
            ang = robot.inverse(end)
            ang = ang * 180 / pi
            _, new_first, new_second = ang
            target = {'first': new_first, 'second': new_second}
            print('pressed command is 8')
    
        else:
            print("pressed command is " + command)

def angles_callback(msg):
        global angles
        print("Angle recieved" + str(msg))
        #angles = {'first': msg.first, 'second': msg.second}

def go_to_pos1():
    global target , is_preset
    target = {'first': 0, 'second': 0}
    is_preset = True

def go_to_pos2():
    global target , is_preset
    target = {'first': 10, 'second': 20}
    is_preset = True



def start():
    global node , subscriber_angle , subscriber_arm , publisher
    rclpy.init(args=None)
    node = rclpy.create_node('Arm_Server')
    publisher = node.create_publisher(String,'/arm_angle_server',10)
    subscriber_arm = node.create_subscription(String, '/arm_controller_server', arm_callback, 10)
    subscriber_angle = node.create_subscription(String, '/angle_feedback_server', angles_callback, 10)
    print('Arm server started')


def pub():
     global publisher , node , command
     msgToSend = String()
     msgToSend.data =  command
     publisher.publish(msgToSend)
     node.get_logger().info(' Publishing : "%s"' % msgToSend.data)

def main():

    global command , node 
    global is_preset ,  subscriber_angle , subscriber_arm

    start()
    rclpy.spin(node)
  
    while True : 

        subscriber_angle = node.create_subscription(String, '/angle_feedback_server', angles_callback, 10)
        subscriber_arm = node.create_subscription(String, '/arm_controller_server', arm_callback, 10)
        
    #node.destroy_node()
    #rclpy.shutdown()

if __name__ == "__main__":
     main()

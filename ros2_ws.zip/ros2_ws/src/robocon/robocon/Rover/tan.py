import pygame
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
import math

# Initialize Pygame and ROS 2
pygame.init()
pygame.joystick.init()

rclpy.init(args=None)
node = rclpy.create_node('joystick_control')
publisher= node.create_publisher(Float32, '/arm_commands', 10)

# List to hold the joystick instances
joysticks = []

def pub():
    global publisher_rover,node
    
    msg = Float32()

    for joystick in joysticks:
        per = joystick.get_axis(1) 
        base = joystick.get_axis(0)

        print("per: ", per, " base: ", base)
        temp:float = (-1*per/base)
    
        # if(abs(base)<=0.2):
        #     temp = -1 * per * 100000

        print("temp: ", temp)
        


        theta = math.atan(temp)

        if (base < 0):
            theta = theta + 3.14
        
        if(theta>3.14):
            theta -= 2*3.14
        if(theta < 0 ):
            theta += 2*3.14

        msg.data = theta
        print(theta)

        publisher.publish(msg)


def process_events():
    global joysticks
    for event in pygame.event.get():
        if event.type == pygame.JOYDEVICEADDED:
            joystick = pygame.joystick.Joystick(event.device_index)
            joystick.init()
            joysticks.append(joystick)
        elif event.type == pygame.JOYBUTTONDOWN:
           # print(f"Button {event.button} pressed")
            pass
        elif event.type == pygame.JOYAXISMOTION:
           # print(f"Axis {event.axis} moved to {event.value:.2f}")
            pass

def main():
    global run
    run = True

    while run:
        process_events()
        pub()
        rclpy.spin_once(node, timeout_sec=0.1) 

        if joysticks and joysticks[0].get_button(10):
            run = False

    pygame.quit()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

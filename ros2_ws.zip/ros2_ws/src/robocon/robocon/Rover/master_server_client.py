import asyncio
import websockets
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist

Ip = "localhost"
port_arm = 8765
port_chassis = 8766
port_gps = 8768

async def connect_and_send(uri, message):
    while True:
        try:
            async with websockets.connect(uri) as websocket:
                await websocket.send(message)
                break  # Exit the loop if the message is sent successfully
        except (websockets.exceptions.ConnectionClosed, ConnectionRefusedError):
            print(f"Connection to {uri} closed. Reconnecting...")
            await asyncio.sleep(2)  # Wait before trying to reconnect

async def arm_callback(msg):
    global recieved_arm

    recieved_arm = msg.data
    print(f"Command: {recieved_arm}")

    uri_arm = f"ws://{Ip}:{port_arm}"
    mesg = json.dumps({"command": recieved_arm})
    await connect_and_send(uri_arm, mesg)

async def chassis_callback(msg):
    x = msg.linear.x
    y = msg.linear.y
    p = msg.linear.z
    ang_z = msg.angular.z

    print(f"Command: x={x}, y={y}, z={p}, ang_z={ang_z}")

    uri_chassis = f"ws://{Ip}:{port_chassis}"
    mesg = json.dumps({
        "linear": {"x": x, "y": y, "z": p},
        "angular": {"z": ang_z}
    })
    await connect_and_send(uri_chassis, mesg)

async def receive_gps_data():
    uri_gps = f"ws://{Ip}:{port_gps}"

    while True:
        try:
            async with websockets.connect(uri_gps) as websocket:
                while True:
                    gps_data = await websocket.recv()
                    gps_data = json.loads(gps_data)
                    print(f"Received GPS data: {gps_data}")
        except (websockets.exceptions.ConnectionClosed, ConnectionRefusedError):
            print("Connection to GPS server closed. Reconnecting...")
            await asyncio.sleep(2)  # Wait before trying to reconnect

def subscribers(node):
    node.create_subscription(Int32, '/arm_client', lambda msg: asyncio.ensure_future(arm_callback(msg)), 10)
    node.create_subscription(Twist, '/rover_client', lambda msg: asyncio.ensure_future(chassis_callback(msg)), 10)

async def main_async():
    rclpy.init(args=None)
    node = rclpy.create_node('Master_Client')

    subscribers(node)

    # Start receiving GPS data
    asyncio.create_task(receive_gps_data())

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            await asyncio.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

def main():
    asyncio.run(main_async())

if __name__ == '__main__':
    main()

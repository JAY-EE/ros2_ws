import asyncio
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist

UDP_SERVER_IP = "localhost"
UDP_SERVER_PORT = 9999

class UDPClientProtocol(asyncio.DatagramProtocol):
    def __init__(self):
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport

    def datagram_received(self, data, addr):
        print(f"Received data: {data.decode('utf-8')}")

async def send_to_udp_server(message):
    loop = asyncio.get_running_loop()
    connect = loop.create_datagram_endpoint(lambda: UDPClientProtocol(), remote_addr=(UDP_SERVER_IP, UDP_SERVER_PORT))
    transport, protocol = await connect
    transport.sendto(message.encode('utf-8'))
    print(f"Sent message: {message}")
    await asyncio.sleep(1)  # Wait for message to be sent and processed
    transport.close()

async def arm_callback(msg):
    received_arm = msg.data
    print(f"Command: {received_arm}")

    message = json.dumps({"command": received_arm})
    await send_to_udp_server(message)

async def chassis_callback(msg):
    x = msg.linear.x
    y = msg.linear.y
    p = msg.linear.z
    ang_z = msg.angular.z

    print(f"Command: x={x}, y={y}, z={p}, ang_z={ang_z}")

    message = json.dumps({
        "linear": {"x": x, "y": y, "z": p},
        "angular": {"z": ang_z}
    })
    await send_to_udp_server(message)

def subscribers(node):
    node.create_subscription(Int32, '/arm_client', lambda msg: asyncio.ensure_future(arm_callback(msg)), 10)
    node.create_subscription(Twist, '/rover_client', lambda msg: asyncio.ensure_future(chassis_callback(msg)), 10)

async def main_async():
    rclpy.init(args=None)
    node = rclpy.create_node('Player_Client')

    subscribers(node)

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            await asyncio.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

def main():
    asyncio.run(main_async())

if __name__ == '__main__':
    main()

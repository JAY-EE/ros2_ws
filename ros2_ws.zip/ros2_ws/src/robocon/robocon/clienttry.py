import asyncio
import websockets
import json
import pygame
import time

async def client():
    uri = "ws://localhost:8765"
    async with websockets.connect(uri) as websocket:
        # Initialize pygame and the joystick
        pygame.init()
        pygame.joystick.init()
        
        # Check if there's at least one joystick connected
        if pygame.joystick.get_count() == 0:
            print("No joystick detected.")
            return

        joystick = pygame.joystick.Joystick(0)
        joystick.init()
        
        print(f"Joystick connected: {joystick.get_name()}")

        while True:
            pygame.event.pump()  # Process pygame events
            
            # Get joystick input data
            axes = [joystick.get_axis(i) for i in range(joystick.get_numaxes())]
            buttons = [joystick.get_button(i) for i in range(joystick.get_numbuttons())]
            hat = joystick.get_hat(0) if joystick.get_numhats() > 0 else (0, 0)

            # Create a JSON object with joystick data
            message = {
                "axes": axes,
                "buttons": buttons,
                "hat": hat
            }
            json_message = json.dumps(message)
            
            # Send the JSON data
            await websocket.send(json_message)

            # Receive and print the server's response
            response = await websocket.recv()
            response_data = json.loads(response)
            print(f"Response from server: {response_data}")

            # Delay to control the frequency of sending data (e.g., every 100ms)
            await asyncio.sleep(0.1)  # Adjust delay as needed

asyncio.run(client())

import asyncio
import websockets

async def function(websocket, path):
    while True:
        data = await websocket.recv()
        print(f"Received: {data}")
        await websocket.send(f"Server received: {data}")

async def main():
    async with websockets.serve(function, "localhost", 8765) :
        await asyncio.Future()



if __name__ == "__main__":
    asyncio.run(main())


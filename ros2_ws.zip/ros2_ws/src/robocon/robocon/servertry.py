import asyncio
import websockets
import json

async def function(websocket, path):
    while True:
        try:
            # Receive data from the client
            data = await websocket.recv()

            # Parse the JSON data
            message = json.loads(data)
            print(f"Received joystick data: {message}")

            # Example of processing joystick data
            axes = message.get("axes", [])
            buttons = message.get("buttons", [])
            hat = message.get("hat", (0, 0))

            # Process joystick data (for demonstration, we'll just print it)
            print(f"Axes: {axes}")
            print(f"Buttons: {buttons}")
            print(f"Hat: {hat}")

            # Prepare a JSON response
            response = {
                "status": "success",
                "received_data": {
                    "axes": axes,
                    "buttons": buttons,
                    "hat": hat
                }
            }

            # Send the JSON response back to the client
            await websocket.send(json.dumps(response))

        except websockets.ConnectionClosed:
            print("Connection closed")
            break
        except json.JSONDecodeError:
            print("Received non-JSON data")
            await websocket.send(json.dumps({"error": "Invalid JSON data"}))

async def main():
    async with websockets.serve(function, "localhost", 8765):
        await asyncio.Future()  # Run forever

if __name__ == "__main__":
    asyncio.run(main())

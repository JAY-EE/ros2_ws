import asyncio
import websockets
import threading
import rclpy
from rclpy.node import Node
from rclpy.qos import *
from std_msgs.msg import String
import time

message = 'j'
node = None
publisher1 = None
publisher2 = None
sserver = None

async def call(websocket, path):
    global message , node , publisher , sserver
    while True:
        try:
            message = await websocket.recv()
            print(f"Received message from client: {message}")
            await websocket.send(f"Received your message: {message}")

            msgToSend = String()
            msgToSend.data = message
            publisher1.publish(msgToSend)
            publisher2.publish(msgToSend)
            
            node.get_logger().info(' Sent character: "%s"' % msgToSend.data)
            await asyncio.sleep(0.01)

        except websockets.exceptions.ConnectionClosedError:
            sserver = await websockets.serve(call, "192.168.29.226", 8765)
            #await sserver.wait_closed()
            print("Reconnecting ..")
            continue

async def start_server():
    global node, publisher1 , publisher2 , sserver
    rclpy.init(args=None)
    node = rclpy.create_node('xyz')
    publisher1 = node.create_publisher(String,'/arm_controller_server',10)
    publisher2 = node.create_publisher(String,'/angle_feedback_server',10)
    sserver = await websockets.serve(call, "192.168.29.226", 8765)  # Listen on all interfaces
    print("Server started")
    await sserver.wait_closed()


#class Time_Publisher(Node):
   # global message
    #def __init__(self):
      #  super().__init__('Time_Publisher')
       # publisher = self.create_publisher(String,'/arm_controller_server',10)
       # msgToSend = String()
       # while True:
       #     msgToSend.data = message
        #    publisher.publish(msgToSend)
        #    self.get_logger().info(' Sent character: "%s"' % msgToSend.data)
        #    time.sleep(0.01)
            

def main(args=None):
    global node
    rclpy.init(args=args)
    #node = Time_Publisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    asyncio.run(start_server())
    main()
    

import cv2
import socket
import struct
import threading
import time


# Ip = 'localhost'

Ip = '192.168.1.10'


# Function to check available camera indices
def find_available_cameras():
    available_cameras = []
    for i in range(10):  # Test indices 0 through 9
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            available_cameras.append(i)
            cap.release()
    return available_cameras

# Function to send video feed from a specific camera
def send_camera_feed(camera_index, server_address):
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    while True:
        cap = cv2.VideoCapture(camera_index)
        if not cap.isOpened():
            print(f"Failed to open camera index {camera_index}") 
            continue 
        ret , frame = cap.read()
        h, w = frame.shape[:2]
        print(h,w)
        if h == 376 :
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)  # Use very small resolution
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 120)
            cap.set(cv2.CAP_PROP_FPS, 30) 
        else :
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 160)  # Use very small resolution
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 120)
            cap.set(cv2.CAP_PROP_FPS, 30)  # Limit FPS to reduce processing overhead

        print(f"Starting video feed for camera index {camera_index}")

        while True:
            ret, frame = cap.read()
            if not ret:
                print(f"Camera index {camera_index} feed ended.")
                break

            # Compress the frame using JPEG
            
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 80]  # Lower quality
             # Compression quality (80% here)
            result, compressed_frame = cv2.imencode('.jpg', frame, encode_param)
            # Compress the frame using JPEG
            if not result:
                print(f"Failed to compress frame for camera index {camera_index}")
                break

            # Send compressed frame
            try:
                udp_socket.sendto(
                    struct.pack("Q", len(compressed_frame)) + compressed_frame.tobytes(),
                    server_address
                )
            except Exception as e:
                print(f"Error sending data for camera index {camera_index}: {e}")
                continue

        print(f"Stopping video feed for camera index {camera_index}")
        continue

def main():
    # Find available cameras
    available_cameras = find_available_cameras()
    if not available_cameras:
        print("No cameras found.")
        return

    print(f"Available cameras: {available_cameras}")

    # Server address
    server_address = (Ip, 9999)

    # Create and start a thread for each camera
    threads = []
    for camera_index in available_cameras:
        print(f"Initializing thread for camera index {camera_index}")
        thread = threading.Thread(
            target=send_camera_feed, args=(camera_index, server_address)
        )
        threads.append(thread)
        thread.start()
        time.sleep(0.5)  # Slight delay to avoid conflicts

    # Wait for all threads to finish
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    main()

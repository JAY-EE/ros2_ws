import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json
import random

rclpy.init()
node = Node('Random_Zed_Server')
zed_pub = node.create_publisher(String, '/zed_cardinal', 10)

def get_cardinal_direction(degree):
    if (degree >= 0 and degree < 22.5) or (degree >= 337.5 and degree < 360):
        return "North"
    elif (degree >= 22.5 and degree < 67.5):
        return "North-East"
    elif (degree >= 67.5 and degree < 112.5):
        return "East"
    elif (degree >= 112.5 and degree < 157.5):
        return "South-East"
    elif (degree >= 157.5 and degree < 202.5):
        return "South"
    elif (degree >= 202.5 and degree < 247.5):
        return "South-West"
    elif (degree >= 247.5 and degree < 292.5):
        return "West"
    elif (degree >= 292.5 and degree < 337.5):
        return "North-West"

def main():
    try:
        while True:
            # Generate random degree between 0 and 360
            degree = random.uniform(0, 360)
            
            # Get the cardinal direction based on the random degree
            cardinal_direction = get_cardinal_direction(degree)
            
            # Create a message with random values
            msg_zed = {
                "degree": degree,
                "dir": cardinal_direction
            }
            
            # Create a String message to publish
            msg = String()
            msg.data = json.dumps(msg_zed)
            zed_pub.publish(msg)
            
            print(f"Random Direction: {degree:.2f}° - {cardinal_direction}")
            
            # Sleep for a short time (optional) to mimic regular updates
            rclpy.spin_once(node, timeout_sec=1)

    except KeyboardInterrupt:
        print("\nExiting...")

if __name__ == "__main__":
    main()

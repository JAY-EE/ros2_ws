import asyncio
import websockets
import numpy as np
import json
import base64
import cv2


async def receive_frames():
    uri = "ws://localhost:8769"  # WebSocket server address

    async with websockets.connect(uri) as websocket:
        print(f"Connected to server at {uri}")

        while True:
            # Wait for the message from the server
            message = await websocket.recv()

            # Parse the JSON message
            data = json.loads(message)
            frame_base64 = data['frame']

            # Decode the base64 string to get the original frame bytes
            frame_bytes = base64.b64decode(frame_base64)

            # Convert the bytes back to an OpenCV frame
            np_frame = np.frombuffer(frame_bytes, dtype=np.uint8)
            frame = cv2.imdecode(np_frame, cv2.IMREAD_COLOR)

            # Display the frame using OpenCV
            cv2.imshow("Received Frame", frame)

            # Exit if the user presses 'q'
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cv2.destroyAllWindows()


if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(receive_frames())

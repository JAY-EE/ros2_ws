import cv2
import socket
import struct
import numpy as np
import subprocess
import time
import tkinter as tk
from tkinter import ttk


# Ip = "localhost"

Ip = '0.0.0.0'

text_options = [
    "Latitude = 15.393293 m, Longitude = 73.881010 m, Altitude = 61 m", #gaddha
    "Latitude = 15.393095 m, Longitude = 73.881065 m, Altitude = 63 m", #pahaad
    "Latitude = 15.393202 m, Longitude = 73.881131 m, Altitude = 61 m", #circle
    "Latitude = 15.393112 m, Longitude = 73.88140 m, Altitude = 61 m", #4th
]



def get_text_selection():
    """Create a dialog window for text selection"""
    result = {"selected_text": None}
    
    def on_select():
        result["selected_text"] = combo.get()
        root.quit()
        root.destroy()
    
    root = tk.Tk()
    root.title("Select Text for Screenshot")
    
    # Center the window
    window_width = 300
    window_height = 150
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - window_width) // 2
    y = (screen_height - window_height) // 2
    root.geometry(f"{window_width}x{window_height}+{x}+{y}")
    
    # Add combobox for text selection
    label = ttk.Label(root, text="Select text to add to screenshot:")
    label.pack(pady=10)
    
    combo = ttk.Combobox(root, values=text_options, state="readonly")
    combo.set(text_options[0])  # Set default value
    combo.pack(pady=10)
    
    # Add confirmation button
    button = ttk.Button(root, text="Confirm", command=on_select)
    button.pack(pady=10)
    
    root.mainloop()
    return result["selected_text"]

# Set up UDP socket
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
udp_socket.bind((Ip, 9999))
udp_socket.settimeout(0.5)  # Avoid indefinite blocking

buffers = {}
frames = {}

ros_command = ["ros2", "topic", "echo", "/gps_publisher"]
process = subprocess.Popen(ros_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

ros_command2 = ["ros2", "topic", "echo", "/gps_publisher2"]
process2 = subprocess.Popen(ros_command2, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


gps_data = "Waiting for GPS data..."  # Default message

gps_data2 = "Waiting for velocity data..."

gps_data_history = []  # Stores history of GPS data
gps_data2_history = []  # Stores history of velocity data
history_limit = 1

last_update_time = time.time()
update_interval = 0.1 

# Desired grid cell size
cell_width, cell_height = 600, 450
data_section_height = 120  # Height of the space reserved for GPS data

def resize_with_aspect_ratio(image, target_width, target_height):
    """Resize an image to fit within a target size, preserving aspect ratio with padding."""
    h, w = image.shape[:2]
    # print(h,w)
    scale = min(target_width / w, target_height / h)
    print(scale)
    resized = cv2.resize(image, (int(w * scale), int(h * scale)))
    h2, w2 = resized.shape[:2]
    if h == 376:
    # Crop the left half of the frame (from the leftmost part to the center)
        w2 = resized.shape[1]  # Updated width after initial resizing
        resized = resized[:, :w2//2]
        
        # Now resize to double the current size
        resized = cv2.resize(resized, (resized.shape[1] * 2, resized.shape[0] * 2))

    # Create a black canvas
    canvas = np.zeros((target_height, target_width, 3), dtype=np.uint8)

    # Center the resized image on the canvas
    y_offset = (target_height - resized.shape[0]) // 2
    x_offset = (target_width - resized.shape[1]) // 2
    canvas[y_offset:y_offset + resized.shape[0], x_offset:x_offset + resized.shape[1]] = resized

    return canvas

# Create a named window for full-screen display
# cv2.namedWindow("All Cameras", cv2.WND_PROP_FULLSCREEN)
# cv2.setWindowProperty("All Cameras", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

print("Receiver is running... Press 'q' to quit.")
screenshot_counter=0
while True:
    try:
        # Receive data
        current_time = time.time()
        packet, source = udp_socket.recvfrom(65536)
        if source not in buffers:
            buffers[source] = b""  # Initialize buffer for this source

        buffers[source] += packet

        # Process complete frames for this source
        if len(buffers[source]) >= 8:
            frame_size = struct.unpack("Q", buffers[source][:8])[0]

            if len(buffers[source]) >= frame_size + 8:
                frame_data = buffers[source][8:frame_size + 8]
                buffers[source] = buffers[source][frame_size + 8:]  # Remove processed data

                # Decode compressed frame
                frame = cv2.imdecode(np.frombuffer(frame_data, dtype=np.uint8), cv2.IMREAD_COLOR)

                if frame is None:
                    print(f"Failed to decode frame from {source}")
                    continue

                # Store the frame for this source
                frames[source] = frame

        # Read GPS data from the ROS process
        # if process.poll() is None:
        #     output_line = process.stdout.readline()
        #     if output_line:
        #         gps_data = output_line.strip()

        # if process2.poll() is None:
        #     output_line = process2.stdout.readline()
        #     if output_line:
        #         gps_data2 = output_line.strip()+
        
        # if process.poll() is None:
        #     output_line = process.stdout.readline().strip()
        #     if output_line:
        #         gps_data_history.append(output_line)  # Add new data to history
        #         if len(gps_data_history) > history_limit:
        #             gps_data_history.pop(0)  # Remove the oldest data

        # if process2.poll() is None:
        #     output_line2 = process2.stdout.readline().strip()
        #     if output_line2:
        #         gps_data2_history.append(output_line2)  # Add new data to history
        #         if len(gps_data2_history) > history_limit:
        #             gps_data2_history.pop(0) 
        if current_time - last_update_time >= update_interval:
        # Read GPS data from the ROS process
            if process.poll() is None:
                output_line = process.stdout.readline().strip()
                if output_line:
                    if not output_line == "---" :
                        gps_data_history.append(output_line)  # Add new data to history
                    if len(gps_data_history) > history_limit:
                        gps_data_history.pop(0)  # Remove the oldest data

            # Read velocity data
            if process2.poll() is None:
                output_line2 = process2.stdout.readline().strip()
                if output_line2:
                    if not output_line2 == "---" :
                        gps_data2_history.append(output_line2)   # Add new data to history
                    if len(gps_data2_history) > history_limit:
                        gps_data2_history.pop(0)  # Remove the oldest data

            last_update_time = current_time

        # Create a composite frame
        if frames:
            # Resize frames to fit within their grid cells, maintaining aspect ratio
            resized_frames = {
                src: resize_with_aspect_ratio(frame, cell_width, cell_height) for src, frame in frames.items()
            }

            # Arrange frames in a grid
            # num_frames = 3
            grid_size = 3  # Determine grid size (e.g., 2x2, 3x3)
            blank_frame = np.zeros((cell_height, cell_width, 3), dtype=np.uint8)  # Black placeholder frame

            # Fill the grid with frames
            grid = []
            current_row = []
            for i, frame in enumerate(resized_frames.values()):
                current_row.append(frame)
                if (i + 1) % grid_size == 0:
                    grid.append(np.hstack(current_row))
                    current_row = []
            if current_row:  # Add the last row if it's incomplete
                while len(current_row) < grid_size:
                    current_row.append(blank_frame)  # Fill with blank frames
                grid.append(np.hstack(current_row))

            # Combine all rows to form the final grid
            composite_frame = np.vstack(grid)

            # Add the data section
            full_height = composite_frame.shape[0] + data_section_height
            full_width = composite_frame.shape[1]
            final_frame = np.zeros((full_height, full_width, 3), dtype=np.uint8)
            final_frame[:composite_frame.shape[0], :composite_frame.shape[1]] = composite_frame

            # # Display the GPS data in the reserved section
            # font = cv2.FONT_HERSHEY_SIMPLEX
            # # cv2.putText(final_frame, f"GPS Data: {gps_data}", (45, composite_frame.shape[0] + 50), font, 0.8, (0, 255, 0), 1, cv2.LINE_AA)
            # # cv2.putText(final_frame, f"Velocity Data: {gps_data}", (650, composite_frame.shape[0] + 50), font, 0.8, (0, 255, 0), 1, cv2.LINE_AA)
            # y_offset = 30
            # for i, gps in enumerate(reversed(gps_data_history)):  # Display newest data first
            #     cv2.putText(final_frame, f"GPS : {gps}", (45, y_offset), font, 0.6, (0, 255, 0), 1, cv2.LINE_AA)
            #     y_offset += 20

            # y_offset = 30
            # for i, gps in enumerate(reversed(gps_data_history)):  # Display newest data first
            #     cv2.putText(final_frame, f"Velocity : {gps}", (650, y_offset), font, 0.6, (0, 255, 0), 1, cv2.LINE_AA)
            #     y_offset += 20

            # y_offset = 30
            # for i, gps in enumerate(reversed(gps_data_history)):  # Display newest data first
            #     cv2.putText(final_frame, f"Encoder feedback : {gps}", (1300, y_offset), font, 0.6, (0, 255, 0), 1, cv2.LINE_AA)
            #     y_offset += 20
            # # Show the final frame
            cv2.imshow("All Cameras", final_frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('s'):
                # Get text selection from user
                selected_text = get_text_selection()
                if selected_text:
                    # Create a copy of the frame to add text
                    screenshot_frame = final_frame.copy()
                    
                    # Add the selected text to the frame
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    text_color = (0, 255, 255)  # Yellow color
                    text_size = 1.2
                    text_thickness = 2
                    
                    # Calculate text size and position
                    (text_width, text_height), _ = cv2.getTextSize(
                        selected_text, font, text_size, text_thickness)
                    text_x = (screenshot_frame.shape[1] - text_width) // 2
                    text_y = screenshot_frame.shape[0] - 30  # 30 pixels from bottom
                    
                    # Add text with background
                    cv2.putText(screenshot_frame, selected_text,
                              (text_x, text_y), font, text_size,
                              text_color, text_thickness, cv2.LINE_AA)
                    
                    # Save the screenshot
                    screenshot_path = f"screenshot_{screenshot_counter}.png"
                    cv2.imwrite(screenshot_path, screenshot_frame)
                    print(f"Screenshot saved as {screenshot_path} with text: {selected_text}")
                    screenshot_counter += 1

        # Check for quit signal
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    except socket.timeout:
        pass  # Continue to next iteration on timeout

# Clean up
udp_socket.close()
process.terminate()
cv2.destroyAllWindows()

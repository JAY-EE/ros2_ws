import numpy as np 
from math import pi 
from visual_kinematics.RobotSerial import RobotSerial
from visual_kinematics.Frame import Frame
import math

import serial
import time
import json
import serial.tools.list_ports

angle_recieved = {
     "shoulder":0,
     "elbow":0,
}

angle_send = {
     "shoulder":0,
     "elbow":0,
}

def find_serial_port():   
 
    ports = serial.tools.list_ports.comports()
    for port in ports:
        if "ACM" in port.device or "USB" in port.device or "COM" in port.device :
            print(port.device)
            try:
                ser = serial.Serial(port.device, 115200, timeout=1)
                time.sleep(2) 
                
                identification_command = json.dumps({"command": "identify"}) + '\n'
                ser.write(identification_command.encode())

                try :
                    response = ser.readline().decode().strip()
                except UnicodeDecodeError as e:
                        print(f"UTF-8 decode error: {e}")
                        continue
                if response:
                    data = json.loads(response)
                    if data.get("device_type") == "arm":
                        print(f"Connected to {port.device}")
                        return ser
                ser.close()
            except (serial.SerialException, json.JSONDecodeError):
                pass  
    return None

serial_connection =serial.Serial("/dev/ttyUSB0", 115200, timeout=1)
# serial_connection = None

def main():

    global serial_connection, angle_recieved,angle_send


    L1 = .54
    L2 = .54

    x=float(input("enter x coordinate: "))
    y=float(input("enter y coordinate: "))

    while True:
        # if serial_connection is None:
        #     print("Searching for the rover...")
        #     serial_connection = find_serial_port()

        #     if serial_connection:
        #         print("Rover connected!")
        #     else:
        #         print("Rover not found. Retrying...")
        #         time.sleep(2)
        #         continue

        if serial_connection.in_waiting > 0:
                line = serial_connection.readline().decode().rstrip()
                if line:  
                    try:
                        response = json.loads(line)

                        angle_recieved = {
                             "shoulder" : (response.get("shoulder")),
                             "elbow" : response.get("elbow")
                        }

                        print("Recieved Angle :",angle_recieved)
                    except json.JSONDecodeError as e:
                        print(f"JSON parsing error: {e}")
                        print(f"Raw data received: {line}")

        # d,a, alpha, theta
        dh_params = np.array([[0., L1, 0., 135*pi/180],
                            [0., L2, 0., -101*pi/180]])

        robot = RobotSerial(dh_params)

    
        xyz = np.array([[x], [y], [0.]])
        abc = np.array([-0.5 * pi, 0.5* pi,0.])
        end = Frame.from_euler_3(abc, xyz)
        robot.inverse(end)

        # print(f"inverse is successful: {robot.is_reachable_inverse}")
        angles=robot.axis_values
        try:
            
            angle_send = {
                        "shoulder": -angles[0]*(180/math.pi),
                        "elbow": -angles[1]*(180/math.pi),
                        }
            print("Sent Angle:",angle_send)
                    
            serial_connection.write((json.dumps(angle_send) + '\n').encode())


        except serial.SerialException:
            print("Connection lost. Reconnecting...")
            serial_connection.close()
            serial_connection = None

        except Exception as e:
            print(f"Unexpected error: {e}")
            serial_connection.close()
            serial_connection = None

        time.sleep(0.01)

    

if __name__ == "__main__":
    main()

# MASTER CLIENT (RUNS ON BASE)

""" 
Setup the communication from base to rover

# Recive :

1) Arm and Rover commands from joystick (client.py file)
   Arm ---> arm_client
   Rover ---> rover_client

2) GPS and Angles feddback from rover

# Publish :

1) GPS and Angles feedback for GUI and other files
   GPS ---> gps_publisher
   Feedback ---> joint_angles_json

"""

# Things to remeber :
# IP should match with IP of server


import asyncio
import websockets
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from final_rover.msg import ArmClient as Arm, GpsMsg  

Ip = "localhost"

# Ip = "192.168.1.10"     # Rover IP (Should match from master_server)

# Channels should match server channel ..
port_arm = 8765
port_chassis = 8766
port_feedback = 8767
port_gps = 8768
port_science = 8769
port_zed = 8770


# Global Variables
websocket_arm = None
websocket_rover = None
websocket_science = None
websocket_zed = None
gps_data = GpsMsg()
feedback_data = 0

# Joint Angles
joint1 = 0
joint2 = 0
joint3 = 0

# GPS data
longi = 0
lati = 0 
alti = 0

# ZED data
degree = 0
cardinal = 0 


async def receive_gps_data():       # Recieve GPS from rover

    global gps_data, gps_data_obj, lati,alti,longi
    uri_gps = f"ws://{Ip}:{port_gps}"

    while True:
        try:
            async with websockets.connect(uri_gps) as websocket:
                while True:
                    received_data = await websocket.recv()
                    gps_data = json.loads(received_data)

                    # Update the gps_data with received values
                    gps_data_obj = GpsMsg()
                    gps_data_obj.longitude = gps_data.get('longitude', 0.0)
                    gps_data_obj.latitude = gps_data.get('latitude', 0.0)
                    gps_data_obj.altitude = gps_data.get('altitude', 0.0)

                    longi = gps_data.get('longitude', 0.0)
                    lati = gps_data.get('latitude', 0.0)
                    alti = gps_data.get('altitude', 0.0)
                    print(f"Received GPS data: {gps_data_obj}")

        except (websockets.exceptions.ConnectionClosed, ConnectionRefusedError):
            print("Connection to GPS server closed. Reconnecting...")
            await asyncio.sleep(2)  # For Reconnect



async def receive_feedback_data():        # Recieve Feedback from Rover 

    global feedback_data, joint1, joint2, joint3
    uri_feedback = f"ws://{Ip}:{port_feedback}"

    while True:
        try:
            async with websockets.connect(uri_feedback) as websocket:
                while True:
                    received_data = await websocket.recv()
                    feedback_data = json.loads(received_data)

                    # Update the global joint angles
                    joint1 = feedback_data.get('joint1', 0.0)
                    joint2 = feedback_data.get('joint2', 0.0)
                    joint3 = feedback_data.get('joint3', 0.0)
                    print(f"Received feedback data: {feedback_data}")

        except (websockets.exceptions.ConnectionClosed, ConnectionRefusedError):
            print("Connection to feedback server closed. Reconnecting...")
            await asyncio.sleep(2)  # For Reconnect


async def receive_zed_data():        # Recieve zed from Rover 

    global degree, cardinal
    uri_zed = f"ws://{Ip}:{port_zed}"

    while True:
        try:
            async with websockets.connect(uri_zed) as websocket:
                while True:
                    received_data = await websocket.recv()
                    zed_data = json.loads(received_data)

                    # Update the global joint angles
                    degree = zed_data.get('deg', 0.0)
                    cardinal = zed_data.get('dir', 0.0)
                    print(f"Received zed data: {zed_data}")

        except (websockets.exceptions.ConnectionClosed, ConnectionRefusedError):
            print("Connection to zed server closed. Reconnecting...")
            await asyncio.sleep(2)  # For Reconnect



class WebSocketClient(Node):
    def __init__(self):
        super().__init__('Master_Client_Node')

        # Create Subscription 
        self.create_subscription(Arm, '/arm_client', self.callback_arm, 10)
        self.create_subscription(Twist, '/rover_client', self.callback_chassis, 10)
        self.create_subscription(String,'/science_client',self.callback_science,10)

        # Create Publishers 
        self.pub_angle = self.create_publisher(String, '/joint_angles_json', 10)
        self.pub_gps = self.create_publisher(String,'/gps_publisher',10)
        self.pub_zed = self.create_publisher(String,'/zed_data',10)
        
        self.gps = gps_data

        # Start the WebSocket Connection
        self.loop = asyncio.get_event_loop()
        self.loop.create_task(receive_gps_data())
        self.loop.create_task(receive_feedback_data())
        self.loop.create_task(receive_zed_data())
        self.loop.create_task(self.setup_connections())



    async def setup_connections(self):           # Setup Communication
        global websocket_arm, websocket_rover, websocket_science, websocket_zed

        try:
            websocket_arm = await websockets.connect(f'ws://{Ip}:{port_arm}', ping_interval=20, ping_timeout=10)
            websocket_rover = await websockets.connect(f'ws://{Ip}:{port_chassis}', ping_interval=20, ping_timeout=10)
            websocket_science = await websockets.connect(f'ws://{Ip}:{port_science}', ping_interval=20, ping_timeout=10)
            # websocket_zed = await websockets.connect(f'ws://{Ip}:{port_zed}', ping_interval=20, ping_timeout=10)
            self.get_logger().info("Connected to WebSocket server")
        except Exception as e:
            self.get_logger().error(f"Failed to connect to WebSocket server: {e}")
            await asyncio.sleep(3)                # Retry Connection
            await self.setup_connections() 



    def callback_arm(self, data):           # Recieve Arm commands from Arm joystick 
        global joint1, joint2, joint3  

        message = {
            'arm': {
                'y': data.y,
                'command': data.command,
                'position': data.position,
                'pitch': data.pitch,
                'yaw': data.yaw,
                'gripper': data.gripper,
                'base': data.base
            }
        }

        joint_angles = {             # Publishing angles for GUI
            "encoder": joint1, 
            "angle1": joint2,
            "angle2": joint3
        }
        json_data = json.dumps(joint_angles)
        msg = String()
        msg.data = json_data

        # Send arm data to server
        asyncio.create_task(self.send_arm_server(message))

        # publish angles for simulation
        self.pub_angle.publish(msg)



    async def send_arm_server(self, message):    # Sends the Arm commands to rover !
        global websocket_arm

        if websocket_arm:
            try:
                await websocket_arm.send(json.dumps(message))
                self.get_logger().info(f"Sent to Arm : {message}")
            except websockets.exceptions.ConnectionClosedError as e:
                self.get_logger().error(f"Connection closed to arm. Reconnecting ... : {e}")
                await self.setup_connections()
                await self.send_arm_server(message)
            except Exception as e:
                self.get_logger().error(f"Error: {e}")
        else:
            self.get_logger().warn("WebSocket connection to arm server is not established yet.")



    def callback_chassis(self, msg):              # Recieve Rover data from Rover josytick
        global gps_data, gps_data_obj, longi, alti , lati
        global degree, cardinal

        x = msg.linear.x
        y = msg.linear.y
        p = msg.linear.z
        ang_z = msg.angular.z

        message = {
            "linear": {"x": x, "y": y, "z": p},
            "angular": {"z": ang_z}
        }

    
        gps_msg = {                       # Publish GPS data recieved
            "longitude": longi , 
            "latitude": lati,
            "altitude": alti
        }
        json_data = json.dumps(gps_msg)
        gps_pub_msg = String()
        gps_pub_msg.data = json_data

        zed_msg = String()
        zed_msg.data = f"Current Direction: {degree:.2f}° - {cardinal}"

        # Send chassis data 
        asyncio.create_task(self.send_rover_server(message))

        # publish gps
        self.pub_gps.publish(gps_pub_msg)
        self.pub_zed.publish(zed_msg)


    async def send_rover_server(self, msg):       # Sends the Rover commands to rover.
        global websocket_rover

        if websocket_rover:
            try:
                await websocket_rover.send(json.dumps(msg))
                self.get_logger().info(f"Sent to Rover : {msg}")
            except websockets.exceptions.ConnectionClosedError as e:
                self.get_logger().error(f"Connection to rover. Reconnecting ... : {e}")
                await self.setup_connections()
                await self.send_rover_server(msg)
            except Exception as e:
                self.get_logger().error(f"Error : {e}")
        else:
            self.get_logger().warn("WebSocket connection to rover server is not established yet.")


    def callback_science(self,message):

        msg = json.loads(message.data)

        pump1_pwm = msg.get("pump1_pwm",0)
        pump2_pwm = msg.get("pump2_pwm",0)
        step_fwd = msg.get("step_fwd",0)
        step_rev = msg.get("step_rev",0)

        msg_science = {
            "pump1_pwm":pump1_pwm,
            "pump2_pwm":pump2_pwm,
            "step_fwd":step_fwd,
            "step_rev":step_rev
        }

        asyncio.create_task(self.send_science_server(msg_science))


    async def send_science_server(self, msg):       # Sends the Science module commands to rover.
        global websocket_science

        if websocket_science:
            try:
                await websocket_science.send(json.dumps(msg))
                self.get_logger().info(f"Sent to Science : {msg}")
            except websockets.exceptions.ConnectionClosedError as e:
                self.get_logger().error(f"Connection to science. Reconnecting ... : {e}")
                await self.setup_connections()
                await self.send_science_server(msg)
            except Exception as e:
                self.get_logger().error(f"Error : {e}")
        else:
            self.get_logger().warn("WebSocket connection to science server is not established yet.")



async def main_async():          # Intialise the base server and communication.
    rclpy.init(args=None)
    node = WebSocketClient()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            await asyncio.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


def main():
    asyncio.run(main_async())


if __name__ == '__main__':
    main()
import asyncio
import websockets
import json
import cv2
import base64
import rclpy
import threading
from rclpy.node import Node
from threading import Lock


Ip = 'localhost'    # Permanent IP of rover
port_video = 8769


class WebSocketServer(Node):
    def __init__(self):
        super().__init__('Master_Server_Node')
        self._video_lock = Lock()

        # Event loop through threading
        self.loop = asyncio.new_event_loop()
        self.websocket_thread = threading.Thread(target=self._run_websocket_server, daemon=True)
        self.websocket_thread.start()

    async def video_server(self, websocket, path):
        # Open the camera (0 is typically the default camera)
        cap = cv2.VideoCapture(0)

        if not cap.isOpened():
            print("Error: Could not open camera.")
            return
        
        while True:
            # Capture a frame from the camera
            ret, frame = cap.read()
            if not ret:
                print("Error: Failed to capture frame.")
                continue

            # Encode the frame as JPEG
            _, buffer = cv2.imencode('.jpg', frame)
            encoded_frame = base64.b64encode(buffer).decode('utf-8')

            # Send the frame to the client
            message = json.dumps({"frame": encoded_frame})
            await websocket.send(message)
            print("Sent frame to client.")

            await asyncio.sleep(0.05)  # Send frame at ~20 fps

    async def start_server(self):
        video_server = await websockets.serve(self.video_server, Ip, port_video, ping_timeout=None)
        self.get_logger().info(f"WebSocket server started on ws://{Ip}:{port_video}")

        await video_server.wait_closed()

    def _run_websocket_server(self):
        # Run the server in a separate thread
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self.start_server())
        self.loop.run_forever()

    def run(self):
        # Execute the threads of ROS2
        executor = rclpy.executors.MultiThreadedExecutor()
        executor.add_node(self)
        try:
            executor.spin()
        except KeyboardInterrupt:
            pass


def main(args=None):
    rclpy.init(args=args)
    server = WebSocketServer()
    try:
        server.run()
    except KeyboardInterrupt:
        pass
    finally:
        server.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


# MASTER CLIENT (RUNS ON BASE)

""" 
Setup the communication from base to rover

1) Arm commands from joystick (client.py file)
   Arm ---> arm_client
"""


import serial
import serial.tools.list_ports
import numpy as np
from math import pi
from visual_kinematics.RobotSerial import RobotSerial, Frame
import asyncio
import json
import rclpy
import time
from rclpy.node import Node
from std_msgs.msg import String

# ===========================
# Global Variables
# ===========================
arm_message = {'y': 0, 'command': 0, 'position': 0, 'pitch': 0, 'yaw': 0, 'gripper': 0, 'base': 0}
angles = {'first': 0, 'second': 0}
target = {'first': 0, 'second': 0}
isPreset = False
speed = 5

rec_y = 0
command = 0
position = 0
pitch = 0
yaw = 0
gripper = 0
base = 0
encoder = False

serial_connection = None

# Robot kinematics setup
np.set_printoptions(precision=3, suppress=True)
dh_params = np.array([[4.5, 4.0, -0.5*pi, 0.5 * pi],
                      [0.0, 54.55, 0.0, -0.5 * pi],
                      [0.0, 54.55, 0.0, 0.5 * pi]])
robot = RobotSerial(dh_params)

# ===========================
# Callback
# ===========================
def callback_arm(message):
    global arm_message, command, position, pitch, yaw, gripper, base

    msg = json.loads(message.data)
    arm_message = {
        'y': msg.get("y", 0),
        'command': msg.get("command", 0),
        'position': msg.get("position", 0),
        'pitch': msg.get("pitch", 0),
        'yaw': msg.get("yaw", 0),
        'gripper': msg.get("gripper", 0),
        'base': msg.get("base", 0)
    }

    command = arm_message['command']
    position = arm_message['position']
    pitch = arm_message['pitch']
    yaw = arm_message['yaw']
    gripper = arm_message['gripper']
    base = arm_message['base']


# ===========================
# Serial Port Scanner
# ===========================
def find_serial_port():
    ports = serial.tools.list_ports.comports()
    for port in ports:
        if "ACM" in port.device or "USB" in port.device:
            try:
                ser = serial.Serial(port.device, 115200, timeout=None)
                time.sleep(2)
                ser.write(json.dumps({"command": "identify"}).encode() + b'\n')
                try:
                    response = ser.readline().decode().strip()
                except UnicodeDecodeError:
                    continue
                data = json.loads(response)
                if data.get("device_type") == "arm":
                    print(f"Connected to {port.device}")
                    return ser
                ser.close()
            except (serial.SerialException, json.JSONDecodeError):
                pass
    return None


# ===========================
# Main Async ROS + Loop
# ===========================
async def main_async():
    global serial_connection, encoder, rec_y, angles, target, command, position, gripper, pitch, yaw, base, isPreset

    rclpy.init()
    node = Node('arm_server')
    node.create_subscription(String, '/arm_client', callback_arm, 10)

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.01)

            if serial_connection is None:
                print("Searching for the arm ..")
                serial_connection = find_serial_port()
                if serial_connection:
                    print("Arm connected!")
                else:
                    print("Arm not found. Retrying ...")
                    await asyncio.sleep(2)
                    continue

            angle_rad = {
                'first': angles['first'] * pi / 180,
                'second': angles['second'] * pi / 180,
            }

            theta = np.array([0, angle_rad['first'], angle_rad['second']])
            f = robot.forward(theta)
            x, y_, z = f.t_3_1.reshape([3, ])

            if encoder:
                if command == 119:  # 'w'
                    isPreset = False
                    xyz = np.array([[x], [y_ + speed], [z]])
                    end = Frame.from_euler_3([0, 0, 0], xyz)
                    ang = robot.inverse(end)
                    if ang is not None:
                        ang = ang * 180 / pi
                        _, new_first, new_second = ang
                        target = {'first': new_first, 'second': new_second}
                        angles = target
                elif command == 115:  # 's'
                    isPreset = False
                    xyz = np.array([[x], [y_ - speed], [z]])
                    end = Frame.from_euler_3([0, 0, 0], xyz)
                    ang = robot.inverse(end)
                    if ang is not None:
                        ang = ang * 180 / pi
                        _, new_first, new_second = ang
                        target = {'first': new_first, 'second': new_second}
                        angles = target
                elif not isPreset:
                    target = angles
            else:
                if command == 119:
                    rec_y = 11
                elif command == 115:
                    rec_y = 22
                else:
                    target = angles

            if command == 99:
                target = {'first': 0, 'second': 0}

            response = {
                "Target_1": target['first'],
                "Traget_2": target['second'],
                "Indiviual": rec_y,
                "Pitch": pitch,
                "Yaw": yaw,
                "Gripper": gripper,
                "Base": base
            }

            print(response)

            serial_connection.write((json.dumps(response) + '\n').encode())

            # try:
            #     if serial_connection.in_waiting > 0:
            #         incoming_data = serial_connection.readline().decode(errors='ignore').strip()
            #         try:
            #             response = json.loads(incoming_data)
            #             if 'Angle_1' in response and 'Angle_2' in response:
            #                 angles = {'first': response['Angle_1'], 'second': response['Angle_2']}
            #                 print(angles)
            #         except (json.JSONDecodeError, UnicodeDecodeError):
            #             print("Corrupt or malformed serial data")
            #             continue
            # except serial.SerialException:
            #     print("Serial communication error. Reconnecting...")
            #     serial_connection.close()
            #     serial_connection = None

            await asyncio.sleep(0.01)

    finally:
        node.destroy_node()
        rclpy.shutdown()


def main():
    asyncio.run(main_async())


if __name__ == '__main__':
    main()

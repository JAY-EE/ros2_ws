# MASTER CLIENT (RUNS ON BASE)

"""
Setup the communication from base to rover

1) Sends arm and navigation commands from base
2) Receives telemetry like GPS data from rover
"""

import serial
import serial.tools.list_ports
import json
import time
import asyncio

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

# ===========================
# Global Variables
# ===========================
linear = 0
angular = 0

longi = 0
lati = 10
alti = 40

pump1 = 0
pump2 = 0
step_fwd = 0
step_rev = 0

serial_connection = None


# ===========================
# ROS Callback
# ===========================
def rover_callback(data):  # Read values from /cmd_vel
    global linear, angular
    linear = float(data.linear.x)
    angular = float(data.angular.z)


# ===========================
# Serial Port Scanner
# ===========================
def find_serial_port():
    ports = serial.tools.list_ports.comports()
    for port in ports:
        if "ACM" in port.device or "USB" in port.device:
            try:
                ser = serial.Serial(port.device, 115200, timeout=None)
                time.sleep(2)
                ser.write(json.dumps({"command": "identify"}).encode() + b'\n')
                try:
                    response = ser.readline().decode().strip()
                    data = json.loads(response)
                    if data.get("device_type") == "rover":
                        print(f"Connected to {port.device}")
                        return ser
                except (UnicodeDecodeError, json.JSONDecodeError):
                    pass
                ser.close()
            except serial.SerialException:
                pass
    return None


# ===========================
# Main Async Loop
# ===========================
async def main_async():
    global serial_connection, longi, lati, alti

    rclpy.init()
    node = Node('rover_server')
    node.create_subscription(Twist, '/rover_client', rover_callback, 10)

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.01)

            if serial_connection is None:
                print("Searching for the rover ..")
                serial_connection = find_serial_port()
                if serial_connection:
                    print("Rover connected!")
                else:
                    print("Rover not found. Retrying ...")
                    await asyncio.sleep(2)
                    continue

            try:
                # Send command to rover
                outgoing_data = {
                    "linear": linear,
                    "angular": angular,
                }
                print(outgoing_data)
                serial_connection.write((json.dumps(outgoing_data) + '\n').encode())

                # Receive data from rover
                if serial_connection.in_waiting > 0:
                    line = serial_connection.readline().decode(errors='ignore').strip()
                    if line:
                        try:
                            incoming_data = json.loads(line)
                            l = incoming_data.get('linear', 0)
                            a = incoming_data.get('angular', 0)
                            print(f"Linear: {l}, Angular: {a}")
                        except json.JSONDecodeError as e:
                            print(f"JSON Error: {e}")
                            print(f"Raw data: {line}")

            except serial.SerialException:
                print("Serial connection error. Reconnecting...")
                if serial_connection:
                    serial_connection.close()
                serial_connection = None

            await asyncio.sleep(0.01)

    finally:
        node.destroy_node()
        rclpy.shutdown()


def main():
    asyncio.run(main_async())


if __name__ == '__main__':
    main()


# MASTER SERVER (RUNS ON ROVER)

""" 
Setup the communication from rover to base

# Recive :

1) Arm and Rover commands from base sataion (Websocket) (master_client.py file)
   Arm ---> arm_port
   Rover ---> rover_port

2) GPS and Angles feedback from (arm_server.py and rover_server.py)
   Feedback Angles ---> encoder_angles
   GPS ---> gps_data

# Publish :

1) Arm and Rover commands to pyserial python files
   Arm ---> arm_server_controller
   Rover ---> cmd_vel

"""


import asyncio
import websockets
import json
import rclpy
import threading
from rclpy.node import Node
from std_msgs.msg import String
from final_rover.msg import ArmClient, GpsMsg as gps    
from geometry_msgs.msg import Twist
from threading import Lock
import pyzed.sl as sl
import math
import time
from datetime import datetime, timedelta


Ip = 'localhost'    # Permannet IP of rover 

# Ip = "192.168.1.8"

# Channel ... Should be the same on master server and client !
port_arm = 8765          
port_chassis = 8766
port_feedback = 8767
port_gps = 8768
port_science = 8769
port_zed = 8770

degree = 0
cardinal_dir = 0


COMMAND_TIMEOUT = 1  # failsafe timing 1 sec


class WebSocketServer(Node):
    def __init__(self):
        super().__init__('Master_Server_Node')

        # Locks for thread-safe data access
        self._gps_lock = Lock()
        self._joint_lock = Lock()
        self._arm_lock = Lock()
        self._chassis_lock = Lock()
        self._science_lock = Lock()
        self._zed_lock = Lock()

        # Initialize data varibales
        self._gps_data = None
        self._joint_data = None
        self._joint1_angle = 0
        self._joint2_angle = 0
        self._joint3_angle = 0

        
        # For fail safe timing
        self._last_arm_command_time = datetime.now()
        self._last_chassis_command_time = datetime.now()
        self._last_science_command_time = datetime.now()

        # Publishers and subscribers
        self.pub_arm = self.create_publisher(ArmClient, '/arm_controller_server', 10)
        self.pub_chassis = self.create_publisher(Twist, '/cmd_vel', 10)
        self.pub_science = self.create_publisher(String,'/science_controller',10)

        self.create_subscription(
            gps,
            '/gps_data',
            self.gps_callback,
            10
        )

        self.create_subscription(
            String,
            '/encoder_angle',
            self.angle_callback,
            10
        )

        self.create_subscription(
            String,
            'zed_cardinal',
            self.zed_callback,
            10
        )

        # Event looping through threding
        self.loop = asyncio.new_event_loop()
        self.websocket_thread = threading.Thread(target=self._run_websocket_server, daemon=True)
        self.websocket_thread.start()


    def gps_callback(self, msg):      # Data comiing from Rover ESP through rover_server file 
        with self._gps_lock:
            self._gps_data = msg
            self.get_logger().info(f"GPS received: {msg}")



    def angle_callback(self, msg):    # Data coming from Arm ESP through arm_server file
        with self._joint_lock:
            try:                      # Read the angles value from encoder/ (sent to base)
                joint_data = json.loads(msg.data)
                self._joint1 = joint_data.get("joint1", 0)
                self._joint2 = joint_data.get("joint2", 0)
                self._joint3 = joint_data.get("joint3", 0)
                self._joint_data = joint_data
                self.get_logger().info(f"Feedback received: {joint_data}")
            except Exception as e:
                self.get_logger().error(f"Error in angle_callback: {e}")

    def zed_callback(self,msg):
        global degree, cardinal_dir
        data = json.loads(msg.data) 
        degree = data.get("degree", 0)
        cardinal_dir = data.get("dir", 0)
        
    async def zed_cardinal(self,websocket,path):
        global degree, cardinal_dir
        try:
            with self._zed_lock:
                await websocket.send(json.dumps({
                    'deg': degree,
                    'dir': cardinal_dir
                }))
                self.get_logger().info(f"ZED Data : Degree : {degree}, Cardinal : {cardinal_dir}")
                await asyncio.sleep(0.1) 
        except Exception as e:
            self.get_logger().error(f"Error in zed_handle: {e}")
            await asyncio.sleep(1)


    async def handle_arm(self, websocket, path):  # Arm commands from base 
        try:

            async for message in websocket:
                self.get_logger().info(f"Received message for arm: {message}")
                data = json.loads(message)
                arm_msg = ArmClient(
                    y=data.get('arm', {}).get('y', 0),
                    command=data.get('arm', {}).get('command', 0),
                    position=data.get('arm', {}).get('position', 0),
                    pitch=data.get('arm', {}).get('pitch', 0),
                    yaw=data.get('arm', {}).get('yaw', 0),
                    gripper=data.get('arm', {}).get('gripper', 0),
                    base=data.get('arm', {}).get('base', 0)
                )
                self.pub_arm.publish(arm_msg)
                with self._arm_lock:
                    self._last_arm_command_time = datetime.now()  # failsafe 
        except Exception as e:
            self.get_logger().error(f"Error in handle_arm: {e}")


    async def handle_chassis(self, websocket, path):      # Rover command from base
        try:
            async for message in websocket:
                self.get_logger().info(f"Received message for rover: {message}")
                data = json.loads(message)
                chassis_command = Twist()
                chassis_command.linear.x = data.get("linear", {}).get("x", 0.0)
                chassis_command.linear.y = data.get("linear", {}).get("y", 0.0)
                chassis_command.linear.z = data.get("linear", {}).get("z", 0.0)
                chassis_command.angular.z = data.get("angular", {}).get("z", 0.0)
                self.pub_chassis.publish(chassis_command)
                with self._chassis_lock:
                    self._last_chassis_command_time = datetime.now()  #failsafe 
        except Exception as e:
            self.get_logger().error(f"Error in handle_chassis: {e}")


    async def handle_science(self, websocket, path):
        try:
            async for message in websocket:
                self.get_logger().info(f"Received message for science: {message}")
                data = json.loads(message)
                science_command = String()
                science_command.data = json.dumps({
                    "pump1_pwm": data.get("pump1_pwm", 0),
                    "pump2_pwm": data.get("pump2_pwm", 0),
                    "step_fwd": data.get("step_fwd", 0),
                    "step_rev": data.get("step_rev", 0)
                })
                self.pub_science.publish(science_command)
                with self._science_lock:
                    self._last_science_command_time = datetime.now()  # failsafe 
        except Exception as e:
                self.get_logger().error(f"Error in handle_science: {e}")


    async def gps_handle(self, websocket, path):      # send gps back to base 
        while True:
            try:
                with self._gps_lock:
                    gps_data = self._gps_data

                if gps_data is not None:
                    await websocket.send(json.dumps({
                        'longitude': gps_data.longitude,
                        'latitude': gps_data.latitude,
                        'altitude': gps_data.altitude
                    }))
                    self.get_logger().info(f"GPS sent : {gps_data}")
                await asyncio.sleep(0.1) 
            except Exception as e:
                self.get_logger().error(f"Error in gps_handle: {e}")
                await asyncio.sleep(1)



    async def feedback_handle(self, websocket, path):  #send feedback from server to base 
        while True:
            try:
                with self._joint_lock:
                    joint1, joint2, joint3 = self._joint1, self._joint2, self._joint3

                await websocket.send(json.dumps({
                    'joint1': joint1,
                    'joint2': joint2,
                    'joint3': joint3
                }))
                self.get_logger().info(f"Feedback Angles : joint1 : {joint1}, joint2 : {joint2}, joint3 : {joint3} ")
                await asyncio.sleep(0.1) 
            except Exception as e:
                self.get_logger().error(f"Error in feedback_handle: {e}")
                await asyncio.sleep(1)



    async def monitor_timeouts(self):            # failsafe mechanism 
        while True:
            now = datetime.now()
            # Handle arm timeout
            with self._arm_lock:
                if (now - self._last_arm_command_time).total_seconds() > COMMAND_TIMEOUT:
                    self.get_logger().warning("No arm command received. Sending 0 values.")
                    arm_msg = ArmClient(y=0, command=99, position=0, pitch=0, yaw=0, gripper=0, base=0)
                    self.pub_arm.publish(arm_msg)
            # Handle chassis timeout
            with self._chassis_lock:
                if (now - self._last_chassis_command_time).total_seconds() > COMMAND_TIMEOUT:
                    self.get_logger().warning("No chassis command received. Sending 0 values.")
                    chassis_command = Twist()
                    self.pub_chassis.publish(chassis_command)
            # Handle science timeout
            with self._chassis_lock:
                if (now - self._last_science_command_time).total_seconds() > COMMAND_TIMEOUT:
                    self.get_logger().warning("No science command received. Sending 0 values.")
                    science_command = String()
                    science_command.data = json.dumps({
                        "pump1_pwm": 0,
                        "pump2_pwm": 0,
                        "step_fwd": 0,
                        "step_rev": 0
                    })
                    self.pub_science.publish(science_command)
            await asyncio.sleep(0.01)



    async def start_server(self):     # Intialise the server !!!
        arm_server = await websockets.serve(self.handle_arm, Ip, port_arm, ping_timeout=None)
        chassis_server = await websockets.serve(self.handle_chassis, Ip, port_chassis, ping_timeout=None)
        science_server = await websockets.serve(self.handle_science,Ip,port_science,ping_timeout=None)
        gps_server = await websockets.serve(self.gps_handle, Ip, port_gps, ping_timeout=None)
        feedback_server = await websockets.serve(self.feedback_handle, Ip, port_feedback, ping_timeout=None)
        zed_server = await websockets.serve(self.zed_cardinal,Ip,port_zed,ping_timeout=None)
        self.get_logger().info(f"WebSocket server started on ws://{Ip}")

        await asyncio.gather(
            arm_server.wait_closed(),
            chassis_server.wait_closed(),
            gps_server.wait_closed(),
            feedback_server.wait_closed(),
            science_server.wait_closed(),
            zed_server.wait_closed()
        )


    def _run_websocket_server(self):          # Run the server in a separate thread
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(asyncio.gather(
            self.start_server(),
            self.monitor_timeouts()
        ))
        self.loop.run_forever()



    def run(self):            # execute the threads of ROS2!!!
        executor = rclpy.executors.MultiThreadedExecutor()
        executor.add_node(self)
        try:
            executor.spin()
        except KeyboardInterrupt:
            pass



def main(args=None):         # Run all the functions.
    rclpy.init(args=args)

    server = WebSocketServer()
    try:
        server.run()
    except KeyboardInterrupt:
        pass
    finally:
        server.destroy_node()
        rclpy.shutdown()



if __name__ == '__main__':
    main()

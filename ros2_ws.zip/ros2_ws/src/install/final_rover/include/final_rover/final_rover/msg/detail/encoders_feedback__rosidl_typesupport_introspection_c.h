// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from final_rover:msg/EncodersFeedback.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__ENCODERS_FEEDBACK__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define FINAL_ROVER__MSG__DETAIL__ENCODERS_FEEDBACK__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "final_rover/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_final_rover
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, final_rover, msg, EncodersFeedback)();

#ifdef __cplusplus
}
#endif

#endif  // FINAL_ROVER__MSG__DETAIL__ENCODERS_FEEDBACK__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

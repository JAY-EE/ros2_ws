// generated from rosidl_generator_c/resource/idl.h.em
// with input from final_rover:msg/EncodersFeedback.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__ENCODERS_FEEDBACK_H_
#define FINAL_ROVER__MSG__ENCODERS_FEEDBACK_H_

#include "final_rover/msg/detail/encoders_feedback__struct.h"
#include "final_rover/msg/detail/encoders_feedback__functions.h"
#include "final_rover/msg/detail/encoders_feedback__type_support.h"

#endif  // FINAL_ROVER__MSG__ENCODERS_FEEDBACK_H_

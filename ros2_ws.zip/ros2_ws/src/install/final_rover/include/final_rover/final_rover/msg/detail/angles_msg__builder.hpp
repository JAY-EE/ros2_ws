// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from final_rover:msg/AnglesMsg.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__BUILDER_HPP_
#define FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "final_rover/msg/detail/angles_msg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace final_rover
{

namespace msg
{

namespace builder
{

class Init_AnglesMsg_gripper
{
public:
  explicit Init_AnglesMsg_gripper(::final_rover::msg::AnglesMsg & msg)
  : msg_(msg)
  {}
  ::final_rover::msg::AnglesMsg gripper(::final_rover::msg::AnglesMsg::_gripper_type arg)
  {
    msg_.gripper = std::move(arg);
    return std::move(msg_);
  }

private:
  ::final_rover::msg::AnglesMsg msg_;
};

class Init_AnglesMsg_yaw
{
public:
  explicit Init_AnglesMsg_yaw(::final_rover::msg::AnglesMsg & msg)
  : msg_(msg)
  {}
  Init_AnglesMsg_gripper yaw(::final_rover::msg::AnglesMsg::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_AnglesMsg_gripper(msg_);
  }

private:
  ::final_rover::msg::AnglesMsg msg_;
};

class Init_AnglesMsg_pitch
{
public:
  explicit Init_AnglesMsg_pitch(::final_rover::msg::AnglesMsg & msg)
  : msg_(msg)
  {}
  Init_AnglesMsg_yaw pitch(::final_rover::msg::AnglesMsg::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_AnglesMsg_yaw(msg_);
  }

private:
  ::final_rover::msg::AnglesMsg msg_;
};

class Init_AnglesMsg_second
{
public:
  explicit Init_AnglesMsg_second(::final_rover::msg::AnglesMsg & msg)
  : msg_(msg)
  {}
  Init_AnglesMsg_pitch second(::final_rover::msg::AnglesMsg::_second_type arg)
  {
    msg_.second = std::move(arg);
    return Init_AnglesMsg_pitch(msg_);
  }

private:
  ::final_rover::msg::AnglesMsg msg_;
};

class Init_AnglesMsg_first
{
public:
  explicit Init_AnglesMsg_first(::final_rover::msg::AnglesMsg & msg)
  : msg_(msg)
  {}
  Init_AnglesMsg_second first(::final_rover::msg::AnglesMsg::_first_type arg)
  {
    msg_.first = std::move(arg);
    return Init_AnglesMsg_second(msg_);
  }

private:
  ::final_rover::msg::AnglesMsg msg_;
};

class Init_AnglesMsg_y
{
public:
  Init_AnglesMsg_y()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AnglesMsg_first y(::final_rover::msg::AnglesMsg::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_AnglesMsg_first(msg_);
  }

private:
  ::final_rover::msg::AnglesMsg msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::final_rover::msg::AnglesMsg>()
{
  return final_rover::msg::builder::Init_AnglesMsg_y();
}

}  // namespace final_rover

#endif  // FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__BUILDER_HPP_

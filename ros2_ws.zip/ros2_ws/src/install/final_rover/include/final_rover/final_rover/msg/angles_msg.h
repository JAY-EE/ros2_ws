// generated from rosidl_generator_c/resource/idl.h.em
// with input from final_rover:msg/AnglesMsg.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__ANGLES_MSG_H_
#define FINAL_ROVER__MSG__ANGLES_MSG_H_

#include "final_rover/msg/detail/angles_msg__struct.h"
#include "final_rover/msg/detail/angles_msg__functions.h"
#include "final_rover/msg/detail/angles_msg__type_support.h"

#endif  // FINAL_ROVER__MSG__ANGLES_MSG_H_

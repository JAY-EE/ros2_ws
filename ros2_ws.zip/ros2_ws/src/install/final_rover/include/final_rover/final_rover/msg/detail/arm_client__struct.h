// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from final_rover:msg/ArmClient.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__ARM_CLIENT__STRUCT_H_
#define FINAL_ROVER__MSG__DETAIL__ARM_CLIENT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/ArmClient in the package final_rover.
typedef struct final_rover__msg__ArmClient
{
  int32_t y;
  uint8_t command;
  int32_t position;
  int32_t pitch;
  int32_t yaw;
  int32_t gripper;
  int32_t base;
} final_rover__msg__ArmClient;

// Struct for a sequence of final_rover__msg__ArmClient.
typedef struct final_rover__msg__ArmClient__Sequence
{
  final_rover__msg__ArmClient * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} final_rover__msg__ArmClient__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FINAL_ROVER__MSG__DETAIL__ARM_CLIENT__STRUCT_H_

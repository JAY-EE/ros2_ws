// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from final_rover:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__NUM__BUILDER_HPP_
#define FINAL_ROVER__MSG__DETAIL__NUM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "final_rover/msg/detail/num__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace final_rover
{

namespace msg
{

namespace builder
{

class Init_Num_x
{
public:
  Init_Num_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::final_rover::msg::Num x(::final_rover::msg::Num::_x_type arg)
  {
    msg_.x = std::move(arg);
    return std::move(msg_);
  }

private:
  ::final_rover::msg::Num msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::final_rover::msg::Num>()
{
  return final_rover::msg::builder::Init_Num_x();
}

}  // namespace final_rover

#endif  // FINAL_ROVER__MSG__DETAIL__NUM__BUILDER_HPP_

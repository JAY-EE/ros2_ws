// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from final_rover:msg/EncodersFeedback.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__ENCODERS_FEEDBACK__STRUCT_H_
#define FINAL_ROVER__MSG__DETAIL__ENCODERS_FEEDBACK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/EncodersFeedback in the package final_rover.
typedef struct final_rover__msg__EncodersFeedback
{
  double first;
  double second;
} final_rover__msg__EncodersFeedback;

// Struct for a sequence of final_rover__msg__EncodersFeedback.
typedef struct final_rover__msg__EncodersFeedback__Sequence
{
  final_rover__msg__EncodersFeedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} final_rover__msg__EncodersFeedback__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FINAL_ROVER__MSG__DETAIL__ENCODERS_FEEDBACK__STRUCT_H_

// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from final_rover:msg/ArmClient.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__ARM_CLIENT__BUILDER_HPP_
#define FINAL_ROVER__MSG__DETAIL__ARM_CLIENT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "final_rover/msg/detail/arm_client__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace final_rover
{

namespace msg
{

namespace builder
{

class Init_ArmClient_base
{
public:
  explicit Init_ArmClient_base(::final_rover::msg::ArmClient & msg)
  : msg_(msg)
  {}
  ::final_rover::msg::ArmClient base(::final_rover::msg::ArmClient::_base_type arg)
  {
    msg_.base = std::move(arg);
    return std::move(msg_);
  }

private:
  ::final_rover::msg::ArmClient msg_;
};

class Init_ArmClient_gripper
{
public:
  explicit Init_ArmClient_gripper(::final_rover::msg::ArmClient & msg)
  : msg_(msg)
  {}
  Init_ArmClient_base gripper(::final_rover::msg::ArmClient::_gripper_type arg)
  {
    msg_.gripper = std::move(arg);
    return Init_ArmClient_base(msg_);
  }

private:
  ::final_rover::msg::ArmClient msg_;
};

class Init_ArmClient_yaw
{
public:
  explicit Init_ArmClient_yaw(::final_rover::msg::ArmClient & msg)
  : msg_(msg)
  {}
  Init_ArmClient_gripper yaw(::final_rover::msg::ArmClient::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_ArmClient_gripper(msg_);
  }

private:
  ::final_rover::msg::ArmClient msg_;
};

class Init_ArmClient_pitch
{
public:
  explicit Init_ArmClient_pitch(::final_rover::msg::ArmClient & msg)
  : msg_(msg)
  {}
  Init_ArmClient_yaw pitch(::final_rover::msg::ArmClient::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_ArmClient_yaw(msg_);
  }

private:
  ::final_rover::msg::ArmClient msg_;
};

class Init_ArmClient_position
{
public:
  explicit Init_ArmClient_position(::final_rover::msg::ArmClient & msg)
  : msg_(msg)
  {}
  Init_ArmClient_pitch position(::final_rover::msg::ArmClient::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_ArmClient_pitch(msg_);
  }

private:
  ::final_rover::msg::ArmClient msg_;
};

class Init_ArmClient_command
{
public:
  explicit Init_ArmClient_command(::final_rover::msg::ArmClient & msg)
  : msg_(msg)
  {}
  Init_ArmClient_position command(::final_rover::msg::ArmClient::_command_type arg)
  {
    msg_.command = std::move(arg);
    return Init_ArmClient_position(msg_);
  }

private:
  ::final_rover::msg::ArmClient msg_;
};

class Init_ArmClient_y
{
public:
  Init_ArmClient_y()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ArmClient_command y(::final_rover::msg::ArmClient::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_ArmClient_command(msg_);
  }

private:
  ::final_rover::msg::ArmClient msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::final_rover::msg::ArmClient>()
{
  return final_rover::msg::builder::Init_ArmClient_y();
}

}  // namespace final_rover

#endif  // FINAL_ROVER__MSG__DETAIL__ARM_CLIENT__BUILDER_HPP_

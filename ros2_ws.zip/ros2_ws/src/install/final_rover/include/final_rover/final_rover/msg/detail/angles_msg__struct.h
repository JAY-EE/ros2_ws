// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from final_rover:msg/AnglesMsg.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__STRUCT_H_
#define FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/AnglesMsg in the package final_rover.
typedef struct final_rover__msg__AnglesMsg
{
  double y;
  double first;
  double second;
  double pitch;
  double yaw;
  int32_t gripper;
} final_rover__msg__AnglesMsg;

// Struct for a sequence of final_rover__msg__AnglesMsg.
typedef struct final_rover__msg__AnglesMsg__Sequence
{
  final_rover__msg__AnglesMsg * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} final_rover__msg__AnglesMsg__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__STRUCT_H_

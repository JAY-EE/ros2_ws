// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__ANGLES_MSG_HPP_
#define FINAL_ROVER__MSG__ANGLES_MSG_HPP_

#include "final_rover/msg/detail/angles_msg__struct.hpp"
#include "final_rover/msg/detail/angles_msg__builder.hpp"
#include "final_rover/msg/detail/angles_msg__traits.hpp"

#endif  // FINAL_ROVER__MSG__ANGLES_MSG_HPP_

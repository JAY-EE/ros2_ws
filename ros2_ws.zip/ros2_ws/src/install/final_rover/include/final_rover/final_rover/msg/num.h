// generated from rosidl_generator_c/resource/idl.h.em
// with input from final_rover:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__NUM_H_
#define FINAL_ROVER__MSG__NUM_H_

#include "final_rover/msg/detail/num__struct.h"
#include "final_rover/msg/detail/num__functions.h"
#include "final_rover/msg/detail/num__type_support.h"

#endif  // FINAL_ROVER__MSG__NUM_H_

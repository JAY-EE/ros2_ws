// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from final_rover:msg/AnglesMsg.idl
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__STRUCT_HPP_
#define FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__final_rover__msg__AnglesMsg __attribute__((deprecated))
#else
# define DEPRECATED__final_rover__msg__AnglesMsg __declspec(deprecated)
#endif

namespace final_rover
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AnglesMsg_
{
  using Type = AnglesMsg_<ContainerAllocator>;

  explicit AnglesMsg_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->y = 0.0;
      this->first = 0.0;
      this->second = 0.0;
      this->pitch = 0.0;
      this->yaw = 0.0;
      this->gripper = 0l;
    }
  }

  explicit AnglesMsg_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->y = 0.0;
      this->first = 0.0;
      this->second = 0.0;
      this->pitch = 0.0;
      this->yaw = 0.0;
      this->gripper = 0l;
    }
  }

  // field types and members
  using _y_type =
    double;
  _y_type y;
  using _first_type =
    double;
  _first_type first;
  using _second_type =
    double;
  _second_type second;
  using _pitch_type =
    double;
  _pitch_type pitch;
  using _yaw_type =
    double;
  _yaw_type yaw;
  using _gripper_type =
    int32_t;
  _gripper_type gripper;

  // setters for named parameter idiom
  Type & set__y(
    const double & _arg)
  {
    this->y = _arg;
    return *this;
  }
  Type & set__first(
    const double & _arg)
  {
    this->first = _arg;
    return *this;
  }
  Type & set__second(
    const double & _arg)
  {
    this->second = _arg;
    return *this;
  }
  Type & set__pitch(
    const double & _arg)
  {
    this->pitch = _arg;
    return *this;
  }
  Type & set__yaw(
    const double & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__gripper(
    const int32_t & _arg)
  {
    this->gripper = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    final_rover::msg::AnglesMsg_<ContainerAllocator> *;
  using ConstRawPtr =
    const final_rover::msg::AnglesMsg_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      final_rover::msg::AnglesMsg_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      final_rover::msg::AnglesMsg_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__final_rover__msg__AnglesMsg
    std::shared_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__final_rover__msg__AnglesMsg
    std::shared_ptr<final_rover::msg::AnglesMsg_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AnglesMsg_ & other) const
  {
    if (this->y != other.y) {
      return false;
    }
    if (this->first != other.first) {
      return false;
    }
    if (this->second != other.second) {
      return false;
    }
    if (this->pitch != other.pitch) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->gripper != other.gripper) {
      return false;
    }
    return true;
  }
  bool operator!=(const AnglesMsg_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AnglesMsg_

// alias to use template instance with default allocator
using AnglesMsg =
  final_rover::msg::AnglesMsg_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace final_rover

#endif  // FINAL_ROVER__MSG__DETAIL__ANGLES_MSG__STRUCT_HPP_

// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FINAL_ROVER__MSG__ARM_CLIENT_HPP_
#define FINAL_ROVER__MSG__ARM_CLIENT_HPP_

#include "final_rover/msg/detail/arm_client__struct.hpp"
#include "final_rover/msg/detail/arm_client__builder.hpp"
#include "final_rover/msg/detail/arm_client__traits.hpp"

#endif  // FINAL_ROVER__MSG__ARM_CLIENT_HPP_

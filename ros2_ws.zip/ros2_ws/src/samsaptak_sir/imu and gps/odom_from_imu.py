#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, TransformStamped
import tf_transformations
import numpy as np
import tf2_ros

class ImuOdometry(Node):
    def __init__(self):
        super().__init__('imu_odometry_node')
        self.create_subscription(Imu, '/imu_publisher', self.imu_callback, 10)
        self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
        
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        
        self.last_time = None
        self.x = 0.0
        self.y = 0.0
        self.vx = 0.0
        self.vy = 0.0
        self.yaw = 0.0
        self.alpha = 0.98  # Complementary filter coefficient
        
        # IMU bias correction
        self.ax_bias = 0.0
        self.ay_bias = 0.0
        self.prev_ax = 0.0
        self.prev_ay = 0.0
    
    def imu_callback(self, msg: Imu):
        current_time = msg.header.stamp
        current_sec = current_time.sec + current_time.nanosec * 1e-9
        
        if self.last_time is None:
            self.last_time = current_sec
            return
        
        dt = current_sec - self.last_time
        if dt <= 0:
            return
        self.last_time = current_sec
        
        # Read IMU data
        ax = msg.linear_acceleration.x - self.ax_bias
        ay = msg.linear_acceleration.y - self.ay_bias
        gz = msg.angular_velocity.z
        
        # Apply a simple moving average to smooth acceleration
        ax = 0.5 * ax + 0.5 * self.prev_ax
        ay = 0.5 * ay + 0.5 * self.prev_ay
        self.prev_ax = ax
        self.prev_ay = ay
        
        # Estimate orientation using a complementary filter
        q = msg.orientation
        roll, pitch, yaw_from_quat = tf_transformations.euler_from_quaternion([q.x, q.y, q.z, q.w])
        self.yaw = self.alpha * (self.yaw + gz * dt) + (1 - self.alpha) * yaw_from_quat
        
        # Rotate acceleration into world frame
        ax_world = ax * np.cos(self.yaw) - ay * np.sin(self.yaw)
        ay_world = ax * np.sin(self.yaw) + ay * np.cos(self.yaw)
        
        # Integrate velocity with damping to reduce drift
        self.vx = (self.vx + ax_world * dt) * 0.9  # Increased damping
        self.vy = (self.vy + ay_world * dt) * 0.9
        
        # Integrate position
        self.x += self.vx * dt
        self.y += self.vy * dt
        
        # Construct odometry message
        odom_msg = Odometry()
        odom_msg.header.stamp = msg.header.stamp
        odom_msg.header.frame_id = "odom"
        odom_msg.child_frame_id = "base_footprint"
        
        odom_msg.pose.pose.position.x = self.x
        odom_msg.pose.pose.position.y = self.y
        odom_msg.pose.pose.position.z = 0.0
        
        odom_quat = tf_transformations.quaternion_from_euler(0, 0, self.yaw)
        odom_msg.pose.pose.orientation = Quaternion(x=odom_quat[0], y=odom_quat[1], z=odom_quat[2], w=odom_quat[3])
        
        odom_msg.twist.twist.linear.x = self.vx
        odom_msg.twist.twist.linear.y = self.vy
        odom_msg.twist.twist.angular.z = gz
        
        self.odom_pub.publish(odom_msg)
        
        # Publish transformation for odometry frame
        transform = TransformStamped()
        transform.header.stamp = msg.header.stamp
        transform.header.frame_id = "odom"
        transform.child_frame_id = "base_footprint"
        transform.transform.translation.x = self.x
        transform.transform.translation.y = self.y
        transform.transform.translation.z = 0.0
        transform.transform.rotation.x = odom_quat[0]
        transform.transform.rotation.y = odom_quat[1]
        transform.transform.rotation.z = odom_quat[2]
        transform.transform.rotation.w = odom_quat[3]
        
        self.tf_broadcaster.sendTransform(transform)
        
        self.get_logger().debug(f"Published odom TF: pos=({self.x:.2f}, {self.y:.2f}), vel=({self.vx:.2f}, {self.vy:.2f}), yaw={self.yaw:.2f}")

def main(args=None):
    rclpy.init(args=args)
    node = ImuOdometry()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down IMU Odometry node.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu

class IMUSubscriber(Node):
    def __init__(self):
        super().__init__('imu_subscriber')
        self.subscription = self.create_subscription(
            Imu,
            'imu_publisher',
            self.imu_callback,
            10)

    def imu_callback(self, msg):
        # Print orientation
        print("\nOrientation:")
        print(f"  x: {msg.orientation.x:.6f}")
        print(f"  y: {msg.orientation.y:.6f}")
        print(f"  z: {msg.orientation.z:.6f}")
        print(f"  w: {msg.orientation.w:.6f}")
        
        # Print angular velocity
        print("\nAngular Velocity:")
        print(f"  x: {msg.angular_velocity.x:.6f}")
        print(f"  y: {msg.angular_velocity.y:.6f}")
        print(f"  z: {msg.angular_velocity.z:.6f}")
        
        # Print linear acceleration
        print("\nLinear Acceleration:")
        print(f"  x: {msg.linear_acceleration.x:.6f}")
        print(f"  y: {msg.linear_acceleration.y:.6f}")
        print(f"  z: {msg.linear_acceleration.z:.6f}")
        print("-" * 50)

def main():
    rclpy.init()
    imu_subscriber = IMUSubscriber()
    
    try:
        rclpy.spin(imu_subscriber)
    except KeyboardInterrupt:
        pass
    
    imu_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
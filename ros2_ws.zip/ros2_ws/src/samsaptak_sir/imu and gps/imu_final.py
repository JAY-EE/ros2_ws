import time
import math
import serial
import struct
import numpy as np
import threading
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from rclpy.qos import QoSProfile, ReliabilityPolicy

port = "/dev/ttyUSB1"

class IMUData:
    def __init__(self):
        self.angular_velocity = [0.0, 0.0, 0.0]
        self.acceleration = [0.0, 0.0, 0.0]
        self.magnetometer = [0.0, 0.0, 0.0]
        self.angle_degree = [0.0, 0.0, 0.0]
        self.key = 0
        self.buff = {}

    def hex_to_short(self, raw_data):
        try:
            return list(struct.unpack("hhhh", bytearray(raw_data)))
        except struct.error as e:
            print(f"Error unpacking data: {e}")
            return [0, 0, 0, 0]

    def check_sum(self, list_data, check_data):
        return sum(list_data) & 0xff == check_data

    def handle_serial_data(self, raw_data):
        self.buff[self.key] = raw_data
        self.key += 1

        if self.buff.get(0) != 0x55:
            self.key = 0
            return False

        if self.key < 11:
            return False

        data_buff = list(self.buff.values())
        
        try:
            if self.buff[1] == 0x51:  # Acceleration
                if self.check_sum(data_buff[0:10], data_buff[10]):
                    self.acceleration = [self.hex_to_short(data_buff[2:10])[i] / 32768.0 * 16 * 9.8 
                                      for i in range(3)]
                else:
                    print('Acceleration checksum failure')

            elif self.buff[1] == 0x52:  # Angular Velocity
                if self.check_sum(data_buff[0:10], data_buff[10]):
                    self.angular_velocity = [self.hex_to_short(data_buff[2:10])[i] / 32768.0 * 2000 
                                          for i in range(3)]
                else:
                    print('Angular velocity checksum failure')

            elif self.buff[1] == 0x53:  # Angle
                if self.check_sum(data_buff[0:10], data_buff[10]):
                    self.angle_degree = [self.hex_to_short(data_buff[2:10])[i] / 32768.0 * 180 
                                      for i in range(3)]
                else:
                    print('Angle checksum failure')

        except (IndexError, KeyError) as e:
            print(f"Error processing data: {e}")
            
        self.buff = {}
        self.key = 0
        return True

class IMUDriverNode(Node):
    def __init__(self):
        super().__init__('imu_driver_node')
        
        self.declare_parameter('port', port)
        self.declare_parameter('baudrate', 9600)
        self.declare_parameter('frame_id', 'imu_link')
        
        self.port = self.get_parameter('port').value
        self.baudrate = self.get_parameter('baudrate').value
        self.frame_id = self.get_parameter('frame_id').value

        self.imu_data = IMUData()

        qos_profile = QoSProfile(
            depth=10,
            reliability=ReliabilityPolicy.RELIABLE)

        # Initialize IMU message
        self.imu_msg = Imu()
        self.imu_msg.header.frame_id = self.frame_id
        
        # Create publisher
        self.imu_pub = self.create_publisher(Imu, 'imu_publisher', qos_profile)

        # Create timer for publishing
        self.create_timer(0.01, self.publish_data)  # 100Hz

        # Start IMU reading thread
        self.running = True
        self.driver_thread = threading.Thread(target=self.driver_loop)
        self.driver_thread.start()

        self.get_logger().info('IMU Driver Node initialized')

    def get_quaternion_from_euler(self, roll, pitch, yaw):
        qx = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
        qy = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
        qz = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
        qw = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
        return [qx, qy, qz, qw]

    def publish_data(self):
        try:
            # Convert angles to radians
            angle_radian = [math.radians(angle) for angle in self.imu_data.angle_degree]
            quat = self.get_quaternion_from_euler(*angle_radian)

            # Update timestamp
            self.imu_msg.header.stamp = self.get_clock().now().to_msg()

            # Set orientation
            self.imu_msg.orientation.x = quat[0]
            self.imu_msg.orientation.y = quat[1]
            self.imu_msg.orientation.z = quat[2]
            self.imu_msg.orientation.w = quat[3]

            # Set angular velocity (convert to radians/sec)
            self.imu_msg.angular_velocity.x = math.radians(self.imu_data.angular_velocity[0])
            self.imu_msg.angular_velocity.y = math.radians(self.imu_data.angular_velocity[1])
            self.imu_msg.angular_velocity.z = math.radians(self.imu_data.angular_velocity[2])

            # Set linear acceleration
            self.imu_msg.linear_acceleration.x = self.imu_data.acceleration[0]
            self.imu_msg.linear_acceleration.y = self.imu_data.acceleration[1]
            self.imu_msg.linear_acceleration.z = self.imu_data.acceleration[2]

            # Publish message
            self.imu_pub.publish(self.imu_msg)

        except Exception as e:
            self.get_logger().error(f'Error publishing data: {e}')

    def driver_loop(self):
        try:
            with serial.Serial(port=self.port, baudrate=self.baudrate, timeout=0.5) as ser:
                self.get_logger().info('Serial port opened successfully')
                
                while self.running and rclpy.ok():
                    try:
                        buff_count = ser.in_waiting
                        if buff_count > 0:
                            buff_data = ser.read(buff_count)
                            for byte_data in buff_data:
                                self.imu_data.handle_serial_data(byte_data)
                                
                    except serial.SerialException as e:
                        self.get_logger().error(f'Serial error: {e}')
                        break
                        
                    except Exception as e:
                        self.get_logger().error(f'Unexpected error: {e}')
                        continue

        except serial.SerialException as e:
            self.get_logger().error(f'Failed to open serial port: {e}')
            return

    def cleanup(self):
        self.running = False
        if self.driver_thread.is_alive():
            self.driver_thread.join()
        self.get_logger().info('IMU Driver Node cleaned up')

def main():
    rclpy.init()
    node = IMUDriverNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cleanup()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
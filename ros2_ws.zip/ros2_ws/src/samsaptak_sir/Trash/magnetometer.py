import pyzed.sl as sl
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import math
import json


rclpy.init()
node = Node('Zed_Server')
zed_pub = node.create_publisher(String, '/zed_cardinal', 10)

def get_cardinal_direction(degree):
    if (degree >= 0 and degree < 22.5) or (degree >= 337.5 and degree < 360):
        return "North"
    elif (degree >= 22.5 and degree < 67.5):
        return "North-East"
    elif (degree >= 67.5 and degree < 112.5):
        return "East"
    elif (degree >= 112.5 and degree < 157.5):
        return "South-East"
    elif (degree >= 157.5 and degree < 202.5):
        return "South"
    elif (degree >= 202.5 and degree < 247.5):
        return "South-West"
    elif (degree >= 247.5 and degree < 292.5):
        return "West"
    elif (degree >= 292.5 and degree < 337.5):
        return "North-West"
    
def main():
    # Create a Camera object
    zed = sl.Camera()

    # Create an InitParameters object and configure settings
    init_params = sl.InitParameters()
    init_params.camera_resolution = sl.RESOLUTION.HD720  # Set camera resolution
    init_params.coordinate_units = sl.UNIT.METER         # Set units (e.g., meters)

    # Open the camera
    if zed.open(init_params) != sl.ERROR_CODE.SUCCESS:
        print("Failed to open the camera.")
        return

    # Create a SensorsData object to store sensor data
    sensors_data = sl.SensorsData()
    try:
        while True:
            # Retrieve sensors data
            if zed.get_sensors_data(sensors_data, sl.TIME_REFERENCE.CURRENT) == sl.ERROR_CODE.SUCCESS:
                # Get magnetic field data in microteslas
                magnetic_field = sensors_data.get_magnetometer_data().get_magnetic_field_calibrated()
                
                # Calculate heading in radians and convert to degrees
                radian = math.atan2((-1.0)*magnetic_field[0], magnetic_field[2])
                degree = math.degrees(radian)
                
                # Ensure the degree is between 0 and 360
                if degree < 0:
                    degree += 360

                # Get the cardinal direction
                cardinal_direction = get_cardinal_direction(degree)

                msg_zed = {
                    # "degree" : degree,
                    # "dir" : cardinal_direction

                    "degree" : 30,
                    "dir" : 90
                }

                msg = String()
                msg.data = json.dumps(msg_zed)
                zed_pub.publish(msg)
                
                
                print(f"Current Direction: {degree:.2f}° - {cardinal_direction}")

    except KeyboardInterrupt:
        print("\nExiting...")

    # Close the camera
    zed.close()

if __name__ == "__main__":
    main()

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CompressedImage
from std_msgs.msg import String
from cv_bridge import CvBridge
import cv2
import numpy as np
import threading
import asyncio
import websockets
import json
import base64
from rclpy.callback_groups import ReentrantCallbackGroup
import signal
import sys
import os

# Import the camera manager
try:
    from camera_persistent_id import CameraPersistentIDManager
except ImportError:
    # If running from within ROS2 package
    # from ros2_camera_websocket.camera_persistent_id import CameraPersistentIDManager
    pass

class CameraServer(Node):
    def __init__(self, camera_id=None, camera_name=None, fps=30, websocket_port=9090):
        super().__init__('camera_server')
        
        # Initialize camera manager
        data_dir = os.path.join(os.path.expanduser('~'), '.ros2_camera_ws')
        os.makedirs(data_dir, exist_ok=True)
        config_file = os.path.join(data_dir, 'camera_registry.json')
        self.camera_manager = CameraPersistentIDManager(config_file=config_file)
        
        # Parameters
        self.camera_id = camera_id  # Can be device ID or persistent ID
        self.camera_name = camera_name  # For matching by name
        self.persistent_id = None  # Will be set during initialization
        self.fps = fps
        self.websocket_port = websocket_port
        self.connected_clients = set()
        self.is_running = True
        
        # Initialize camera
        self.cap = None
        self.initialize_camera()
        
        # Publishers for ROS2 topics
        self.raw_publisher = self.create_publisher(
            Image, 
            'camera/image_raw', 
            10
        )
        self.compressed_publisher = self.create_publisher(
            CompressedImage, 
            'camera/image/compressed', 
            10
        )
        
        # Parameter for reconnection attempts
        self.declare_parameter('reconnect_interval', 2.0)
        self.reconnect_interval = self.get_parameter('reconnect_interval').value
        
        # Create timer for camera reconnection attempts
        self.reconnect_timer = self.create_timer(
            self.reconnect_interval,
            self.check_and_reconnect_camera
        )
        
        # Timer for camera frame capture
        self.timer_group = ReentrantCallbackGroup()
        self.timer = self.create_timer(
            1.0/self.fps,
            self.capture_frame,
            callback_group=self.timer_group
        )
        
        # Bridge for ROS <-> OpenCV conversion
        self.bridge = CvBridge()
        
        # Latest frame for websocket clients
        self.latest_frame_jpg = None
        
        # Start WebSocket server
        self.ws_thread = threading.Thread(target=self.run_websocket_server)
        self.ws_thread.daemon = True
        self.ws_thread.start()
        
        # Setup signal handler for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        
        # Publish camera status
        self.camera_status_publisher = self.create_publisher(
            String, 
            'camera/status', 
            10
        )
        self.publish_camera_status("initialized")
        
        self.get_logger().info("Camera Server initialized")
    
    def signal_handler(self, sig, frame):
        """Handle SIGINT for graceful shutdown"""
        self.get_logger().info("Shutdown signal received. Cleaning up...")
        self.is_running = False
        if self.cap and self.cap.isOpened():
            self.cap.release()
        self.camera_manager.stop()
        sys.exit(0)
    
    def publish_camera_status(self, status):
        """Publish camera status to ROS topic"""
        from std_msgs.msg import String
        msg = String()
        
        # Include camera details in the status message
        if self.persistent_id:
            camera_info = self.camera_manager.cameras.get(self.persistent_id, {})
            status_details = {
                "status": status,
                "persistent_id": self.persistent_id,
                "current_device_id": self.camera_id,
                "name": camera_info.get("name", "Unknown"),
                "resolution": f"{camera_info.get('width', 0)}x{camera_info.get('height', 0)}"
            }
            msg.data = json.dumps(status_details)
        else:
            msg.data = json.dumps({"status": status, "error": "No camera identified"})
            
        self.camera_status_publisher.publish(msg)
    
    def initialize_camera(self):
        """Initialize the camera with persistent ID tracking"""
        # Release any existing camera
        if self.cap and self.cap.isOpened():
            self.cap.release()
            self.cap = None
        
        device_id = None
        
        # Case 1: Use persistent ID directly
        if self.camera_id and isinstance(self.camera_id, str) and self.camera_id.startswith("cam_"):
            self.persistent_id = self.camera_id
            device_id = self.camera_manager.get_camera_by_persistent_id(self.persistent_id)
            if device_id is not None:
                self.get_logger().info(f"Found camera with persistent ID {self.persistent_id}, using device ID {device_id}")
            else:
                self.get_logger().warn(f"Camera with persistent ID {self.persistent_id} not currently available")
                return False
        
        # Case 2: Use device ID and lookup/create persistent ID
        elif self.camera_id is not None and isinstance(self.camera_id, (int, str)):
            try:
                device_id = int(self.camera_id)
                # Try to get persistent ID for this device
                self.persistent_id = self.camera_manager.get_persistent_id(device_id)
                if not self.persistent_id:
                    # Will be assigned during next camera scan
                    self.get_logger().info(f"No persistent ID found for device {device_id}, will be assigned after scan")
            except ValueError:
                self.get_logger().error(f"Invalid camera ID: {self.camera_id}")
                return False
        
        # Case 3: Find camera by name
        elif self.camera_name:
            available_cameras = self.camera_manager.get_available_cameras()
            for camera in available_cameras:
                info = self.camera_manager.cameras.get(camera["persistent_id"], {})
                if info.get("name", "").lower() == self.camera_name.lower():
                    self.persistent_id = camera["persistent_id"]
                    device_id = camera["current_device_id"]
                    self.get_logger().info(f"Found camera '{self.camera_name}' with ID {device_id}")
                    break
            
            if device_id is None:
                self.get_logger().error(f"No camera found with name '{self.camera_name}'")
                return False
        
        # Case 4: Use first available camera
        else:
            available_cameras = self.camera_manager.get_available_cameras()
            if available_cameras:
                self.persistent_id = available_cameras[0]["persistent_id"]
                device_id = available_cameras[0]["current_device_id"]
                self.get_logger().info(f"Using first available camera, ID: {device_id}, persistent ID: {self.persistent_id}")
            else:
                self.get_logger().error("No cameras available")
                return False
        
        # Open the camera
        try:
            self.cap = cv2.VideoCapture(device_id)
            if not self.cap.isOpened():
                self.get_logger().error(f"Failed to open camera with device ID {device_id}")
                return False
            
            # Set camera properties
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            
            # Update self.camera_id to current device ID
            self.camera_id = device_id
            
            # Log success
            self.get_logger().info(f"Successfully opened camera with device ID {device_id}, persistent ID: {self.persistent_id}")
            self.publish_camera_status("connected")
            return True
            
        except Exception as e:
            self.get_logger().error(f"Error opening camera: {str(e)}")
            return False
    
    def check_and_reconnect_camera(self):
        """Check if camera is connected and try to reconnect if not"""
        if not self.cap or not self.cap.isOpened():
            self.get_logger().info("Camera disconnected, attempting to reconnect...")
            self.publish_camera_status("reconnecting")
            
            # If we have a persistent ID, try to find it again
            if self.persistent_id:
                device_id = self.camera_manager.get_camera_by_persistent_id(self.persistent_id)
                if device_id is not None:
                    try:
                        self.cap = cv2.VideoCapture(device_id)
                        if self.cap.isOpened():
                            self.camera_id = device_id
                            self.get_logger().info(f"Successfully reconnected to camera {self.persistent_id} (device ID: {device_id})")
                            self.publish_camera_status("connected")
                            return
                    except Exception as e:
                        self.get_logger().error(f"Error reconnecting to camera: {str(e)}")
            
            # If reconnection by persistent ID failed, try to initialize from scratch
            self.initialize_camera()
    
    def capture_frame(self):
        """Capture a frame from the camera and publish it"""
        if not self.is_running or not self.cap or not self.cap.isOpened():
            return
            
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warning("Failed to capture frame")
            # This could mean camera was disconnected
            if self.cap.isOpened():
                self.cap.release()
            return
        
        # Publish raw image to ROS2 topic
        ros_image = self.bridge.cv2_to_imgmsg(frame, "bgr8")
        self.raw_publisher.publish(ros_image)
        
        # Convert to JPEG for WebSocket clients
        _, jpg_data = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        
        # Publish compressed image to ROS2 topic
        compressed_msg = CompressedImage()
        compressed_msg.header.stamp = self.get_clock().now().to_msg()
        compressed_msg.format = "jpeg"
        compressed_msg.data = jpg_data.tobytes()
        self.compressed_publisher.publish(compressed_msg)
        
        # Store latest frame for websocket clients
        self.latest_frame_jpg = jpg_data.tobytes()
    
    async def websocket_handler(self, websocket, path):
        """Handle WebSocket client connections"""
        client_id = id(websocket)
        self.connected_clients.add(websocket)
        self.get_logger().info(f"Client {client_id} connected. Total clients: {len(self.connected_clients)}")
        
        try:
            # Send camera information to client
            camera_info = {
                "type": "camera_info",
                "fps": self.fps,
                "width": int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)) if self.cap and self.cap.isOpened() else 0,
                "height": int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) if self.cap and self.cap.isOpened() else 0,
                "persistent_id": self.persistent_id,
                "device_id": self.camera_id,
                "name": self.camera_manager.cameras.get(self.persistent_id, {}).get("name", "Unknown Camera") 
                       if self.persistent_id else "Unknown Camera"
            }
            await websocket.send(json.dumps(camera_info))
            
            # Keep connection alive and handle client messages
            async for message in websocket:
                try:
                    data = json.loads(message)
                    
                    # Handle client requests
                    if data.get("request") == "frame" and self.latest_frame_jpg:
                        frame_data = {
                            "type": "frame",
                            "data": base64.b64encode(self.latest_frame_jpg).decode('utf-8'),
                            "timestamp": self.get_clock().now().nanoseconds / 1e9,
                            "persistent_id": self.persistent_id,
                            "device_id": self.camera_id
                        }
                        await websocket.send(json.dumps(frame_data))
                    
                    # Handle camera list request
                    elif data.get("request") == "camera_list":
                        camera_list = {
                            "type": "camera_list",
                            "cameras": self.camera_manager.get_available_cameras()
                        }
                        await websocket.send(json.dumps(camera_list))
                    
                    # Handle camera switch request
                    elif data.get("request") == "switch_camera" and "persistent_id" in data:
                        old_id = self.persistent_id
                        self.persistent_id = data["persistent_id"]
                        success = self.initialize_camera()
                        response = {
                            "type": "switch_camera_response",
                            "success": success,
                            "persistent_id": self.persistent_id if success else old_id,
                            "device_id": self.camera_id if success else None
                        }
                        await websocket.send(json.dumps(response))
                        
                except json.JSONDecodeError:
                    self.get_logger().warning(f"Received invalid JSON from client {client_id}")
        except websockets.exceptions.ConnectionClosed:
            self.get_logger().info(f"Client {client_id} disconnected")
        finally:
            self.connected_clients.remove(websocket)
    
    async def broadcast_frames(self):
        """Broadcast frames to all connected clients"""
        while self.is_running:
            if self.latest_frame_jpg and self.connected_clients:
                frame_data = {
                    "type": "frame",
                    "data": base64.b64encode(self.latest_frame_jpg).decode('utf-8'),
                    "timestamp": self.get_clock().now().nanoseconds / 1e9,
                    "persistent_id": self.persistent_id,
                    "device_id": self.camera_id
                }
                frame_json = json.dumps(frame_data)
                
                # Send to all connected clients
                if self.connected_clients:
                    await asyncio.gather(
                        *[client.send(frame_json) for client in self.connected_clients],
                        return_exceptions=True
                    )
            
            # Sleep to control broadcast rate
            await asyncio.sleep(1.0 / self.fps)
    
    async def start_websocket_server(self):
        """Start the WebSocket server"""
        server = await websockets.serve(
            self.websocket_handler, 
            "0.0.0.0", 
            self.websocket_port
        )
        
        # Start frame broadcasting task
        asyncio.create_task(self.broadcast_frames())
        
        self.get_logger().info(f"WebSocket server started on port {self.websocket_port}")
        await server.wait_closed()
    
    def run_websocket_server(self):
        """Run WebSocket server in a separate thread"""
        asyncio.run(self.start_websocket_server())

def main(args=None):
    rclpy.init(args=args)
    
    import argparse
    parser = argparse.ArgumentParser(description='ROS2 Camera WebSocket Server with Persistent IDs')
    parser.add_argument('--camera', type=str, default=None, help='Camera device ID or persistent ID')
    parser.add_argument('--camera-name', type=str, default=None, help='Camera name for identification')
    parser.add_argument('--fps', type=int, default=30, help='Frames per second')
    parser.add_argument('--port', type=int, default=9090, help='WebSocket server port')
    parsed_args = parser.parse_args()
    
    camera_server = CameraServer(
        camera_id=parsed_args.camera,
        camera_name=parsed_args.camera_name,
        fps=parsed_args.fps,
        websocket_port=parsed_args.port
    )
    
    try:
        rclpy.spin(camera_server)
    except KeyboardInterrupt:
        pass
    finally:
        # Clean up
        if camera_server.cap and camera_server.cap.isOpened():
            camera_server.cap.release()
        camera_server.camera_manager.stop()
        camera_server.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
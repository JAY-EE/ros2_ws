#!/usr/bin/env python3

import cv2
import json
import os
import numpy as np
import hashlib
import threading
import time
import logging
from typing import Dict, List, Optional, Tuple, Any
import subprocess
import re

class CameraPersistentIDManager:
    """
    A class that maintains persistent camera identification despite devices being
    unplugged and reattached with different system IDs.
    """
    
    def __init__(self, config_file: str = "camera_registry.json", scan_interval: int = 2):
        """
        Initialize the camera manager.
        
        Args:
            config_file: Path to store camera configurations and fingerprints
            scan_interval: How often to scan for camera changes (in seconds)
        """
        self.config_file = config_file
        self.scan_interval = scan_interval
        self.cameras: Dict[str, Dict[str, Any]] = {}  # Persistent ID -> camera info
        self.device_map: Dict[int, str] = {}  # Current device ID -> Persistent ID
        self.logger = self._setup_logger()
        
        # Load existing camera registry if available
        self._load_registry()
        
        # Start the monitoring thread
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_cameras)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        self.logger.info("Camera Persistent ID Manager initialized")
    
    def _setup_logger(self) -> logging.Logger:
        """Set up logging"""
        logger = logging.getLogger("CameraManager")
        logger.setLevel(logging.INFO)
        
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _load_registry(self) -> None:
        """Load the camera registry from file if it exists"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    self.cameras = json.load(f)
                self.logger.info(f"Loaded camera registry with {len(self.cameras)} cameras")
            except Exception as e:
                self.logger.error(f"Error loading camera registry: {str(e)}")
                self.cameras = {}
    
    def _save_registry(self) -> None:
        """Save the camera registry to file"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.cameras, f, indent=2)
            self.logger.info(f"Saved camera registry with {len(self.cameras)} cameras")
        except Exception as e:
            self.logger.error(f"Error saving camera registry: {str(e)}")
    
    def get_available_cameras(self) -> List[Dict[str, Any]]:
        """
        Get a list of all currently available cameras with their persistent IDs.
        
        Returns:
            List of camera information dictionaries
        """
        return [
            {
                "persistent_id": pid,
                "current_device_id": self._find_current_device_id(pid),
                "name": info.get("name", "Unknown Camera"),
                "resolution": info.get("resolution", "Unknown"),
                "serial": info.get("serial", "Unknown")
            }
            for pid, info in self.cameras.items()
            if self._find_current_device_id(pid) is not None
        ]
    
    def _find_current_device_id(self, persistent_id: str) -> Optional[int]:
        """Find current device ID for a given persistent ID"""
        for dev_id, pid in self.device_map.items():
            if pid == persistent_id:
                return dev_id
        return None
    
    def get_camera_by_persistent_id(self, persistent_id: str) -> Optional[int]:
        """
        Get the current device ID for a camera with the given persistent ID.
        
        Args:
            persistent_id: The persistent identifier for the camera
            
        Returns:
            Current device ID if camera is available, None otherwise
        """
        return self._find_current_device_id(persistent_id)
    
    def get_persistent_id(self, device_id: int) -> Optional[str]:
        """
        Get the persistent ID for a given device ID.
        
        Args:
            device_id: Current system device ID
            
        Returns:
            Persistent ID if known, None otherwise
        """
        return self.device_map.get(device_id)
    
    def get_device_info(self, device_id: int) -> Dict[str, Any]:
        """
        Get detailed info about a camera by its current device ID.
        
        Args:
            device_id: Current system device ID
            
        Returns:
            Dictionary of camera properties
        """
        persistent_id = self.get_persistent_id(device_id)
        if persistent_id and persistent_id in self.cameras:
            info = self.cameras[persistent_id].copy()
            info["current_device_id"] = device_id
            info["persistent_id"] = persistent_id
            return info
        return {
            "current_device_id": device_id,
            "persistent_id": None,
            "name": "Unknown Camera",
            "resolution": "Unknown",
            "serial": "Unknown"
        }
    
    def _get_camera_properties(self, device_id: int) -> Dict[str, Any]:
        """
        Extract properties from a camera to create a fingerprint.
        
        Args:
            device_id: Camera device ID
            
        Returns:
            Dictionary of camera properties
        """
        properties = {}
        
        try:
            # Open the camera
            cap = cv2.VideoCapture(device_id)
            if not cap.isOpened():
                self.logger.warning(f"Could not open camera {device_id}")
                return properties
            
            # Get basic properties
            properties["width"] = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            properties["height"] = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            properties["fps"] = cap.get(cv2.CAP_PROP_FPS)
            
            # Try to get camera name/model
            properties["name"] = self._get_camera_name(device_id)
            
            # Try to get serial number or other unique identifiers
            properties["serial"] = self._get_camera_serial(device_id)
            
            # Capture a test frame for additional verification
            ret, frame = cap.read()
            if ret:
                # Calculate average brightness as part of fingerprint
                # (helps distinguish between identically specified cameras)
                properties["avg_brightness"] = np.mean(frame)
                
                # Create a hash of the initial frame
                # (not fully reliable but adds another data point)
                frame_hash = hashlib.md5(frame.tobytes()).hexdigest()
                properties["frame_hash"] = frame_hash[:10]  # Use first 10 chars
            
            # Release camera
            cap.release()
            
            # Generate fingerprint from combined properties
            fingerprint_str = f"{properties.get('name', '')}_{properties.get('width', 0)}x"\
                             f"{properties.get('height', 0)}_{properties.get('serial', '')}"
            properties["fingerprint"] = hashlib.md5(fingerprint_str.encode()).hexdigest()
            
        except Exception as e:
            self.logger.error(f"Error getting camera {device_id} properties: {str(e)}")
        
        return properties
    
    def _get_camera_name(self, device_id: int) -> str:
        """Attempt to get camera name/model using platform-specific methods"""
        # Try v4l2-ctl on Linux
        try:
            if os.name == 'posix':
                output = subprocess.check_output(
                    ["v4l2-ctl", "--device", f"/dev/video{device_id}", "--all"],
                    stderr=subprocess.DEVNULL,
                    universal_newlines=True
                )
                # Extract camera name from output
                name_match = re.search(r"Card type\s*:\s*(.+)", output)
                if name_match:
                    return name_match.group(1).strip()
        except:
            pass
            
        # Fallback to generic name
        return f"Camera-{device_id}"
    
    def _get_camera_serial(self, device_id: int) -> str:
        """Attempt to get camera serial number using platform-specific methods"""
        # Try v4l2-ctl on Linux
        try:
            if os.name == 'posix':
                output = subprocess.check_output(
                    ["v4l2-ctl", "--device", f"/dev/video{device_id}", "--info"],
                    stderr=subprocess.DEVNULL,
                    universal_newlines=True
                )
                # Extract serial from output - not all cameras expose this
                serial_match = re.search(r"serial\s*:\s*'?([a-zA-Z0-9]+)'?", output)
                if serial_match:
                    return serial_match.group(1).strip()
                
                # Try USB bus info as alternative unique identifier
                bus_match = re.search(r"usb-(\S+)", output)
                if bus_match:
                    return bus_match.group(1).strip()
        except:
            pass
            
        # Generate a pseudo-serial based on other properties as fallback
        cap = cv2.VideoCapture(device_id)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()
        return f"Gen-{width}x{height}-{device_id}"
    
    def _scan_cameras(self) -> List[Tuple[int, Dict[str, Any]]]:
        """
        Scan for all available cameras and their properties.
        
        Returns:
            List of (device_id, properties) tuples
        """
        available_cameras = []
        
        # Method 1: Try OpenCV's range scanning
        for i in range(10):  # Scan potential camera indices
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                cap.release()
                properties = self._get_camera_properties(i)
                available_cameras.append((i, properties))
        
        # Method 2: On Linux, also check /dev/video* devices
        if os.name == 'posix':
            try:
                video_devices = [d for d in os.listdir('/dev') if d.startswith('video')]
                for device in video_devices:
                    try:
                        idx = int(device.replace('video', ''))
                        # Skip if already found
                        if any(i == idx for i, _ in available_cameras):
                            continue
                            
                        cap = cv2.VideoCapture(idx)
                        if cap.isOpened():
                            cap.release()
                            properties = self._get_camera_properties(idx)
                            available_cameras.append((idx, properties))
                    except:
                        pass
            except:
                pass
        
        self.logger.info(f"Scan found {len(available_cameras)} cameras")
        return available_cameras
    
    def _match_camera(self, properties: Dict[str, Any]) -> Optional[str]:
        """
        Match camera properties to a known persistent ID.
        
        Args:
            properties: Camera properties dictionary
            
        Returns:
            Persistent ID if a match is found, None otherwise
        """
        # Method 1: Direct fingerprint match
        fingerprint = properties.get("fingerprint")
        if fingerprint:
            for pid, info in self.cameras.items():
                if info.get("fingerprint") == fingerprint:
                    return pid
        
        # Method 2: Serial number match
        serial = properties.get("serial")
        if serial and serial != "Unknown":
            for pid, info in self.cameras.items():
                if info.get("serial") == serial:
                    return pid
        
        # Method 3: Similar properties match
        for pid, info in self.cameras.items():
            # Match based on resolution and name
            if (info.get("width") == properties.get("width") and
                info.get("height") == properties.get("height") and
                info.get("name") == properties.get("name")):
                return pid
        
        # No match found
        return None
    
    def _update_camera_registry(self, devices: List[Tuple[int, Dict[str, Any]]]) -> None:
        """
        Update the camera registry with currently available cameras.
        
        Args:
            devices: List of (device_id, properties) tuples
        """
        # Reset device mapping
        self.device_map = {}
        
        for device_id, properties in devices:
            # Try to match with existing camera
            persistent_id = self._match_camera(properties)
            
            # If no match found, create new entry
            if not persistent_id:
                # Create new persistent ID (timestamp + partial fingerprint)
                timestamp = int(time.time())
                partial_fingerprint = properties.get("fingerprint", "")[:8]
                persistent_id = f"cam_{timestamp}_{partial_fingerprint}"
                
                # Add to registry
                self.cameras[persistent_id] = properties
                self.logger.info(f"New camera registered with persistent ID: {persistent_id}")
            else:
                # Update existing camera properties
                self.cameras[persistent_id].update(properties)
                self.logger.info(f"Updated camera with persistent ID: {persistent_id}")
            
            # Update device mapping
            self.device_map[device_id] = persistent_id
        
        # Save updated registry
        self._save_registry()
    
    def _monitor_cameras(self) -> None:
        """Monitor cameras and update the registry when changes are detected"""
        while self.running:
            try:
                # Scan for available cameras
                available_cameras = self._scan_cameras()
                
                # Update registry
                self._update_camera_registry(available_cameras)
                
                # Sleep for scan interval
                time.sleep(self.scan_interval)
            except Exception as e:
                self.logger.error(f"Error in camera monitor: {str(e)}")
                time.sleep(self.scan_interval)
    
    def stop(self) -> None:
        """Stop the monitoring thread"""
        self.running = False
        if self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=3.0)
        self.logger.info("Camera Persistent ID Manager stopped")
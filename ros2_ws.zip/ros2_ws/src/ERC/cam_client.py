#!/usr/bin/env python3

import asyncio
import websockets
import json
import cv2
import numpy as np
import base64
import argparse
import signal
import sys

class CameraClient:
    def __init__(self, server_address="localhost", server_port=9090):
        self.server_address = server_address
        self.server_port = server_port
        self.websocket_url = f"ws://{server_address}:{server_port}"
        self.is_running = True
        self.camera_info = None
        
        # Setup signal handler for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        
        print(f"Client initialized. Connecting to: {self.websocket_url}")
    
    def signal_handler(self, sig, frame):
        """Handle SIGINT for graceful shutdown"""
        print("Shutdown signal received. Cleaning up...")
        self.is_running = False
        cv2.destroyAllWindows()
        sys.exit(0)
    
    async def connect_to_server(self):
        """Connect to the WebSocket server and process received frames"""
        try:
            async with websockets.connect(self.websocket_url) as websocket:
                print(f"Connected to server at {self.websocket_url}")
                
                # Initial request for camera info
                await websocket.send(json.dumps({"request": "info"}))
                
                # Process incoming messages
                while self.is_running:
                    try:
                        message = await websocket.recv()
                        data = json.loads(message)
                        
                        if data["type"] == "camera_info":
                            self.camera_info = data
                            print(f"Camera info received: {self.camera_info}")
                        
                        elif data["type"] == "frame":
                            # Decode the frame
                            jpg_data = base64.b64decode(data["data"])
                            frame = cv2.imdecode(np.frombuffer(jpg_data, np.uint8), cv2.IMREAD_COLOR)
                            
                            # Display the frame
                            cv2.imshow("Camera Feed", frame)
                            key = cv2.waitKey(1)
                            
                            # Press 'q' to quit
                            if key == ord('q'):
                                break
                            
                            # Request next frame
                            await websocket.send(json.dumps({"request": "frame"}))
                    
                    except json.JSONDecodeError:
                        print("Received invalid JSON")
                    
                    except Exception as e:
                        print(f"Error processing message: {e}")
        
        except websockets.exceptions.ConnectionClosedError:
            print("Connection closed by server")
        
        except Exception as e:
            print(f"Connection error: {e}")
        
        finally:
            cv2.destroyAllWindows()
            print("Client disconnected")
    
    def run(self):
        """Run the client"""
        try:
            asyncio.run(self.connect_to_server())
        except KeyboardInterrupt:
            print("Client stopped by user")
            cv2.destroyAllWindows()

def main():
    parser = argparse.ArgumentParser(description='ROS2 Camera WebSocket Client')
    parser.add_argument('--server', type=str, default='localhost', help='WebSocket server address')
    parser.add_argument('--port', type=int, default=9090, help='WebSocket server port')
    args = parser.parse_args()
    
    client = CameraClient(server_address=args.server, server_port=args.port)
    client.run()

if __name__ == '__main__':
    main()
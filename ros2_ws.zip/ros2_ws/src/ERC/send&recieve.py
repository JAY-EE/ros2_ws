from SerialConnection import SerialConnection 

# Initialize the connection with a specific device type
serial_conn = SerialConnection(device_type="rover")

while serial_conn.ser:
    n = int(input("Enter the num,ber : "))
    serial_conn.send({"command": "move", "direction": n})
    response = serial_conn.receive()
    if response:
        print("Received:", response)
    else:
        print("No valid serial connection found.")
serial_conn.close()
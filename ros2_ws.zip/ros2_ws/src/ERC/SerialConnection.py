import serial
import time
import json
import serial.tools.list_ports


def find_serial_port():         # Scan available serial ports and 
                                # return the one that responds with 'rover'
    ports = serial.tools.list_ports.comports()
    for port in ports:
        if "ACM" in port.device or "USB" in port.device:
            print(port.device)
            try:
                ser = serial.Serial(port.device, 115200, timeout=1)
                time.sleep(2)  # Some time for the serial connection to stabilize
                
                # Send identification command
                identification_command = json.dumps({"command": "identify"}) + '\n'
                ser.write(identification_command.encode())

                # check wheather data is corrupted or not 
                try :
                    response = ser.readline().decode().strip()
                except UnicodeDecodeError as e:
                        print(f"UTF-8 decode error: {e}")
                        continue
                
                # Read response
                if response:
                    data = json.loads(response)
                    if data.get("device_type") == "rover":
                        print(f"Connected to {port.device}")
                        return ser
                ser.close()
            except (serial.SerialException, json.JSONDecodeError):
                pass  # Try the next port
    return None

serial_connection = None

if serial_connection is None:
        print("Searching for the rover...")
        serial_connection = find_serial_port()

        if serial_connection:
            print("Rover connected!")
        else:
            print("Rover not found. Retrying...")
            time.sleep(2)
            serial_connection = find_serial_port()

def main():

    global serial_connection
    # while True:
     
    # if serial_connection is None:
    #     print("Searching for the rover...")
    #     serial_connection = find_serial_port()

    #     if serial_connection:
    #         print("Rover connected!")
    #     else:
    #         print("Rover not found. Retrying...")
    #         time.sleep(2)
    #         serial_connection = find_serial_port()


    try:
        response = {
                    "command": 3,
                    "direction": 2,
                    }
                
                
        # send repsonse to master-server
        serial_connection.write((json.dumps(response) + '\n').encode())

        time.sleep(0.01)
        
        # Read data from the rover
        if serial_connection.in_waiting > 0:
            line = serial_connection.readline().decode().rstrip()
            if line:  # Check if line is not empty
                try:
                    response = json.loads(line)
                    print(line)
                except json.JSONDecodeError as e:
                    print(f"JSON parsing error: {e}")
                    print(f"Raw data received: {line}")

    except serial.SerialException:
        print("Connection lost. Reconnecting...")
        serial_connection.close()
        serial_connection = None

    except Exception as e:
        print(f"Unexpected error: {e}")
        serial_connection.close()
        serial_connection = None

    

if __name__ == "__main__":
    main()